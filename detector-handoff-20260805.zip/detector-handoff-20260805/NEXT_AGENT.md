# ROME detector handoff

Created: 2026-08-05

Repository: `Security-FIT/Latium`

Branch: `detector-simplification`

Verified commit: `094b162b88ceee042116f2860a245806777cfcd6`

At packaging time, the tracked branch was exactly synchronized with
`origin/detector-simplification` (`0` commits ahead and `0` behind after
`git fetch --prune origin`). The source commit and the archived simplification
evidence are pushed. Several reports and notebooks in the working tree remain
untracked; see `WORKTREE-STATE.md`.

## Read this first

The current detector is `rome-detector-minimal-v3`, exposed through the
`weighted-spectrum` capture/analysis identity. It is a one-checkpoint layer
localizer based on the `diagonal_relative` score. It consumes only the ordered
editable projection matrices from the suspect checkpoint.

It is **not** a binary ROME provenance detector. It must not expose a default
`is_rome` verdict. The development evidence shows that magnitude-matched
non-ROME rank-one edits reproduce the same geometry. No baseline checkpoint,
model name, configured edit layer, causal trace, prompt, covariance, or ROME
request may enter the detector input.

The historical `legacy-spectral-confirmation-v5c` detector is separate. It
uses spectral gap, top-1 energy, local-z windows 5 and 7, and structural
fallbacks. Its optional paper-style `target +/- 1` decision is a
target-conditioned confirmation rule, not a suspect-only provenance
detector. Signal A/B is a third, separate analysis and is not part of the
requested historical confirmation method.

## Current v3 method

For projection weight `W_l`, orient and normalize the hidden Gram:

```text
C_l = hidden_gram(W_l) / ||W_l||_F^2
N_l = (C_(l-1) + C_(l+1)) / 2
R_l = C_l - N_l
```

Let `sigma_1`, `sigma_2` and `u_1`, `u_2` be the leading two singular pairs of
`R_l`. The retained score is:

```text
diagonal_relative_l = sqrt(sum_i (sigma_i / (u_i^T N_l u_i))^2)
selected_layer = argmax_l diagonal_relative_l
```

Eligibility uses one generic 10% fractional boundary trim. Exact ties select
the lower layer. The old 2x2 whitening/M3 computation was removed after the
focused non-inferiority study.

## Latest focused simplification test

The N=20 study requested 260 cases across 13 model families and retained 240
successful ROME edits.

| Metric | Diagonal-relative v3 | M3 control |
|---|---:|---:|
| Exact localization | 196/240 (81.7%) | 198/240 (82.5%) |
| Equal-model macro | 82.7% | 83.5% |
| Within one layer | 201/240 (83.8%) | 203/240 (84.6%) |

The 0.81-point macro loss was inside the predeclared 2.5-point simplification
margin. Twelve of thirteen models tied. Falcon accounted for the two lost
cases (`3/19` versus M3 `5/19`). OLMo remained `0/20` for both methods.

The matched-hard-negative development subset contained 94 successful ROME
edits, five clean checkpoints, and 200 magnitude-matched hard negatives. The
best v3 spike statistic reached only 61.8% macro balanced accuracy. Its
sensitivity was 45.7%, specificity 75.6%, and matched rank-one specificity
48.0%. This is the decisive evidence against a binary provenance output.

The exact raw evidence is nested in
`evidence/rome-simple-gram-evidence-20260728.tar.gz`. Its SHA-256 is
`21571e709cb27b630dc2d75563cca1de17c13b3101ec9d7ea3d6980f555ce961`.

## Latest N=100 fleet test

The later fleet attempted 100 ROME edits on each of 14 models. There were
1,384 successful edits out of 1,400 attempts. On those successful edits,
current `weighted-spectrum` v3 localized:

```text
exact:        1,069 / 1,384 = 77.2%
within +/-1:  1,093 / 1,384 = 79.0%
```

Strong exact results included DeepSeek R1 Llama 8B, Gemma 4 12B, GPT-J,
Llama 2, OPT, Qwen3 4B, Qwen3 8B, and Qwen3.5 4B. Main failures were OLMo
(`0/100`), Falcon (`10/99`), and Granite 4.1 8B (`11/99`). Mistral v0.3 was
`69/93` exact but `93/93` within one.

This fleet contains edited positive checkpoints only. Its localization rate
is not binary accuracy and supplies no TN, FP, specificity, balanced accuracy,
or AUROC.

Original job summaries and logs are in `fleet-n100/raw-results/`. Consolidated
rows are in `fleet-n100/newest-detector-stats.csv` and JSON. Aggregate signal
graphs are included without the hundreds of redundant per-case PNGs.

## Qwen3 8B warning

Do not describe Qwen3 as a general failure. Current weighted-spectrum v3 found
L7 in 95/100 cases, while Qwen3 4B was 100/100 in the N=100 fleet.

The old spectral detector failed Qwen3 8B because all 100 cases selected a
native L5 spectral-gap peak while the new causal/ROME target was L7. The old
paper experiments edited L10, where ROME caused a much larger spectral-gap
change. Increasing the acceptance radius to two would also accept the native
L5 peak on clean Qwen-like checkpoints and is not a valid fix.

## Reproduction and validation

Start from the exact pushed branch:

```bash
git fetch origin
git switch detector-simplification
git pull --ff-only
git rev-parse HEAD
```

Expected HEAD:

```text
094b162b88ceee042116f2860a245806777cfcd6
```

Run the focused surviving tests with the repository import path set:

```bash
PYTHONPATH=. pytest -q \
  tests/test_weighted_spectrum_detector.py \
  tests/test_rome_presence.py \
  tests/test_rome_single_checkpoint_impossibility_evidence.py
```

Packaging verification produced `16 passed` on 2026-08-05. Calling bare
`pytest` without `PYTHONPATH=.` can fail collection with
`ModuleNotFoundError: src` in this environment.

Verify the evidence before using it:

```bash
sha256sum evidence/rome-simple-gram-evidence-20260728.tar.gz
tar -tzf evidence/rome-simple-gram-evidence-20260728.tar.gz | less
```

## Recommended next work

1. Reproduce the frozen v3 aggregate from the archived N=20 profiles before
   changing the score.
2. Treat Falcon, Granite, and OLMo as architecture-neutral localization
   failure analysis. Do not add family names, configured-layer hints, or
   per-family constants.
3. Evaluate every new feature on successful ROME positives, standalone clean
   checkpoints, and magnitude-matched rank-one/rank-two/non-target/multilayer
   negatives.
4. Freeze a global rule on exposed families and evaluate untouched families
   only after the development gates are met.
5. Report micro localization, equal-family macro localization, within-one
   localization, sensitivity, specificity by negative category, macro balanced
   accuracy, worst-family balanced accuracy, and uncertainty intervals.
6. Keep the legacy spectral `target +/- 1` experiment in a separate table. It
   is allowed to answer paper reproduction questions, but it cannot be used as
   evidence for a blind binary detector.
7. Do not claim ROME provenance from a low-rank anomaly unless the matched
   rank-one specificity failure has been resolved under the one-checkpoint
   constraint.

## Reading order

1. `current-detector/docs-detector.md`
2. `current-detector/explain-simplified.md`
3. `reports/rome-simple-gram-simplification-report.md`
4. `reports/rome-single-checkpoint-impossibility-report.md`
5. `reports/test-result.md`
6. `reports/spectral-failure-analysis.md`
7. `reports/legacy-spectral-discrepancy.md`
8. `fleet-n100/newest-detector-stats.csv`

The current implementation and focused unit tests are copied under `source/`
and `tests/` for quick inspection. The Git branch remains the authoritative
source.

## Background-only material

The `background/` directory preserves useful local provenance that is not part
of the current detector implementation:

- `paper.tex` is the paper draft used when comparing the paper-style spectral
  confirmation rule with the current implementation.
- `explain-old-overcomplicated.md` documents a working but overcomplicated old
  method. It is reference material, not the method to restore or deploy.
- `causal-tracing-notebooks/` contains the current, legacy-static, and stable
  Llama 2 causal-tracing comparisons used while investigating layer changes.
- `tools/fetch_failed_spectral_graphs.sh` fetches saved per-case graphs from
  the N=100 jobs when they still exist on the remote results host.

The duplicate local result tarballs are omitted because the latest extracted
summaries and logs are already present under `fleet-n100/raw-results/`.
