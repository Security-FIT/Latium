# Packaging-time Git state

After `git fetch --prune origin` on 2026-08-05:

```text
branch: detector-simplification
HEAD: 094b162b88ceee042116f2860a245806777cfcd6
upstream: origin/detector-simplification
ahead: 0
behind: 0
tracked modifications: none
```

The following workspace files were untracked and therefore are **not** pushed
to the branch:

```text
explain-new.md
explain.md
falcon-olmo-rome-binary-5090-goal.md
jobs/fetch_failed_spectral_graphs.sh
legacy-spectral-discrepancy.md
notebooks/llama2-causal-rome-current.ipynb
notebooks/llama2-causal-rome-legacy-static.ipynb
notebooks/llama2-causal-rome-stable.ipynb
paper.tex
rome-detector-results-latest.tgz
rome-detector-results.tgz
spectral-failure-analysis.md
test-result.md
timing.md
```

Relevant untracked reports and results are copied into this handoff archive.
The notebooks, `paper.tex`, old working explanation, and graph-fetch helper are
included under `background/` and explicitly marked as non-authoritative
reference material. The duplicate result tarballs are intentionally omitted
because their useful latest contents are already extracted under
`fleet-n100/raw-results/`.
