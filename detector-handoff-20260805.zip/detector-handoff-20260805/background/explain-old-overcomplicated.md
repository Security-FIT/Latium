# Ako funguje `weighted-spectrum` detektor ROME editov

## Zrozumiteľný report k lineárnej algebre, motivácii a limitom metódy

Tento report vysvetľuje matematiku v dokumente **Architecture-Neutral Detection of a ROME-Edited Layer**. Cieľom nie je iba prepísať vzorce slovami, ale ukázať:

1. čo jednotlivé objekty znamenajú geometricky,
2. prečo sa v detektore používajú,
3. čo je štandardná lineárna algebra,
4. čo je vlastná heuristika navrhnutého detektora,
5. ktoré tvrdenia platia presne a ktoré iba približne.

---

## 1. Čo sa detektor snaží urobiť

Detektor dostane iba váhy podozrivého modelu. Nemá pôvodný čistý checkpoint, prompt, aktivácie ani informáciu o editovanom fakte. Pre každú MLP output/down-projection vrstvu vytvorí matematický profil a hľadá vrstvu, ktorej profil vyzerá ako lokálna nízkohodnostná anomália.

Dôležité obmedzenie:

> Aktuálna metóda nelíši čistý model od editovaného modelu. Vždy vráti nejakú vrstvu, pretože používa `argmax`.

Správna interpretácia výstupu teda je:

> Za predpokladu, že model obsahuje jeden lokalizovaný ROME-like edit, toto je najpravdepodobnejšia editovaná vrstva.

Nie:

> Model bol určite editovaný pomocou ROME.

---

## 2. Celá metóda v jednej intuitívnej vete

Pre každú vrstvu detektor:

1. prevedie obdĺžnikovú váhovú maticu na štvorcovú maticu opisujúcu geometriu v hidden priestore,
2. odstráni celkovú mierku váh,
3. porovná vrstvu s jej dvoma susedmi,
4. ponechá dve najsilnejšie anomálne smery,
5. zmeria anomáliu relatívne k tomu, koľko energie majú v týchto smeroch susedné vrstvy,
6. vyberie vrstvu s najväčšou relatívnou anomáliou.

Kľúčový reťazec je:

$$
W_l
\longrightarrow
C_l
\longrightarrow
A_l
\longrightarrow
U_l
\longrightarrow
B_l,G_l
\longrightarrow
E_l
\longrightarrow
s_l.
$$

Význam objektov:

| Objekt | Intuitívny význam |
|---|---|
| $W_l$ | pôvodná váhová matica vrstvy |
| $C_l$ | normalizovaná geometria váh v hidden priestore |
| $R_l$ | očakávaný lokálny profil podľa susedov |
| $A_l$ | odchýlka vrstvy od susedného trendu |
| $U_l$ | dva smery s najsilnejšou odchýlkou |
| $B_l$ | veľkosť zmeny v týchto dvoch smeroch |
| $G_l$ | normálna susedná energia v rovnakých smeroch |
| $E_l$ | zmena po prepočítaní vzhľadom na lokálne pozadie |
| $s_l$ | jedno číslo, skóre anomálnosti vrstvy |

---

# Časť I: Základné pojmy

## 3. Vektor, matica a lineárna transformácia

Vektor je usporiadaný zoznam čísel, napríklad

$$
x = \begin{bmatrix}x_1\\x_2\\x_3\end{bmatrix}.
$$

Matica $W$ predstavuje lineárne zobrazenie:

$$
y = Wx.
$$

Ak

$$
W\in\mathbb{R}^{h\times m},
$$

potom vstup $x$ má $m$ komponentov a výstup $y$ má $h$ komponentov.

V transformer MLP typicky:

- $m$ je rozšírený MLP rozmer,
- $h$ je hidden alebo residual-stream rozmer,
- output/down-projection mapuje MLP reprezentáciu späť do residual streamu.

Preto je dôležité, aby konečný profil vrstvy žil v $h$-rozmernom hidden priestore. Hidden priestor je spoločný medzi vrstvami, zatiaľ čo jednotlivé MLP neuróny nemusia mať medzi vrstvami porovnateľnú identitu.

### Poznámka k implementácii

Dokument identifikuje hidden os podľa menšieho rozmeru matice. To zodpovedá bežným transformerom, kde je MLP intermediate rozmer väčší ako hidden rozmer. Nie je to však univerzálna matematická pravda. Robustnejšia implementácia by mala hidden os určovať z architektúrnej konfigurácie alebo z explicitnej roly parametra, nie iba z porovnania rozmerov.

---

## 4. Vonkajší súčin a rank-one matica

Pre dva vektory

$$
a\in\mathbb{R}^{h},\qquad b\in\mathbb{R}^{m}
$$

je ich vonkajší súčin

$$
ab^\top\in\mathbb{R}^{h\times m}.
$$

Jeho prvky sú

$$
(ab^\top)_{ij}=a_i b_j.
$$

Každý stĺpec tejto matice je násobkom vektora $a$:

$$
ab^\top=
\begin{bmatrix}
b_1a & b_2a & \cdots & b_ma
\end{bmatrix}.
$$

Všetky stĺpce preto ležia na jednej priamke určenej vektorom $a$. Matica má rank najviac 1.

### Čo znamená rank

Rank matice je počet nezávislých smerov, ktoré matica dokáže vytvoriť.

- rank 0: nulová matica,
- rank 1: všetky výstupy ležia v jednom smere,
- rank 2: výstupy ležia v rovine,
- vyšší rank: zmena zasahuje viac nezávislých smerov.

ROME zapisuje zmenu váh v tvare

$$
W'=W+ab^\top.
$$

To znamená, že k pôvodnej matici pridá štruktúrovanú zmenu s rankom 1. Presný ROME vzorec používa konkrétne vektory odvodené z nového key-value páru a kovariančnej matice kľúčov, ale z pohľadu detektora je podstatný vonkajší súčin dvoch vektorov.

Pôvodný ROME článok explicitne opisuje edit ako rank-one update MLP projekcie [1].

---

## 5. Gramova matica

### 5.1 Definícia

Pre maticu $W$ môžeme vytvoriť dve príbuzné Gramove matice:

$$
W^\top W
\qquad\text{alebo}\qquad
WW^\top.
$$

Ak stĺpce matice $W$ označíme ako $w_1,\ldots,w_m$, potom

$$
(W^\top W)_{ij}=w_i^\top w_j.
$$

Každý prvok Gramovej matice je teda skalárny súčin dvojice vektorov.

Gramova matica uchováva:

- normy vektorov na diagonále,
- podobnosť a uhol medzi vektormi mimo diagonály,
- geometriu celej množiny vektorov.

Boyd a Vandenberghe definujú Gramovu maticu presne ako maticu všetkých párových vnútorných súčinov stĺpcov [2].

### 5.2 Čo znamená $WW^\top$ v tomto detektore

Predpokladajme

$$
W\in\mathbb{R}^{h\times m}.
$$

Potom

$$
WW^\top\in\mathbb{R}^{h\times h}.
$$

Je to operátor v hidden priestore. Jeho prvky porovnávajú riadky $W$, čiže spôsob, akým jednotlivé hidden výstupné koordináty používajú MLP vstupy.

Ešte užitočnejšia je kvadratická forma:

$$
x^\top WW^\top x
=
\|W^\top x\|_2^2.
$$

Táto rovnica hovorí:

> Pre hidden smer $x$ meria $WW^\top$, ako silno je tento smer podporovaný váhovou maticou $W$.

Preto sa dá $WW^\top$ chápať ako mapa energie alebo podpory v hidden smeroch.

### 5.3 Prečo nepoužiť priamo $W$

Priame porovnanie $W_l-W_{l+1}$ predpokladá, že stĺpec číslo 500 v jednej MLP vrstve zodpovedá stĺpcu číslo 500 v ďalšej vrstve. To vo všeobecnosti nemá jasný význam. Intermediate neuróny sú špecifické pre danú vrstvu.

Naopak, hidden os je spoločný residual-stream súradnicový systém. Prevodom na $WW^\top$ sa intermediate os zosumarizuje a zostane objekt v spoločnom hidden priestore.

To je jedna z najsilnejších motivácií celej metódy.

---

## 6. Prečo je Gramova matica pozitívne semidefinitná

Matica $C$ je pozitívne semidefinitná, ak pre každý vektor $x$ platí

$$
x^\top Cx\geq 0.
$$

Pre Gramovu maticu:

$$
x^\top WW^\top x
=
(W^\top x)^\top(W^\top x)
=
\|W^\top x\|_2^2
\geq 0.
$$

Preto je $WW^\top$ vždy:

- symetrická,
- pozitívne semidefinitná,
- má nezáporné vlastné čísla.

Pozitívne semidefinitné matice sú prirodzené objekty na opis energie, kovariancie alebo geometrickej podpory. MIT materiály k pozitívne semidefinitným maticiam vysvetľujú ekvivalentnú podmienku $x^\top Cx\geq0$ a súvis s faktorizáciou typu $A^\top A$ [3].

---

## 7. Frobeniova norma

Frobeniova norma matice je

$$
\|W\|_F
=
\sqrt{\sum_{i,j}W_{ij}^2}.
$$

Je to obyčajná euklidovská norma všetkých prvkov matice, ak by sme maticu rozbalili do jedného dlhého vektora.

Platí

$$
\|W\|_F^2
=
\operatorname{tr}(WW^\top)
=
\operatorname{tr}(W^\top W).
$$

Kde `trace`, po slovensky stopa matice, je súčet diagonálnych prvkov:

$$
\operatorname{tr}(C)=\sum_i C_{ii}.
$$

Boyd a Vandenberghe uvádzajú Frobeniovu normu ako odmocninu zo súčtu štvorcov všetkých prvkov [2].

---

## 8. Trace normalization

Detektor vytvára

$$
C_l=\frac{W_lW_l^\top}{\|W_l\|_F^2}.
$$

Keďže

$$
\operatorname{tr}(W_lW_l^\top)=\|W_l\|_F^2,
$$

dostaneme

$$
\operatorname{tr}(C_l)=1.
$$

To je význam výrazu **trace-one Gram matrix**.

### 8.1 Prečo sa normalizuje

Ak by jedna vrstva mala všetky váhy dvakrát väčšie,

$$
\widetilde W=2W,
$$

potom

$$
\widetilde W\widetilde W^\top=4WW^\top.
$$

Bez normalizácie by mohla mať vysoké skóre iba kvôli celkovej mierke.

Po normalizácii:

$$
\frac{(2W)(2W)^\top}{\|2W\|_F^2}
=
\frac{4WW^\top}{4\|W\|_F^2}
=
\frac{WW^\top}{\|W\|_F^2}.
$$

Detektor teda ignoruje celkovú veľkosť váh a ponecháva relatívne rozdelenie energie medzi hidden smermi.

### 8.2 Čo sa normalizáciou stráca

Normalizácia zámerne odstraňuje informáciu o absolútnej veľkosti matice. To môže zlepšiť generalizáciu medzi architektúrami, ale môže zároveň odstrániť reálny signál editu v celkovom Frobeniovom norme.

Preto dokument správne ponecháva nenormalizované normové štatistiky ako diagnostické signály, ale nemieša ich do hlavného skóre pomocou ručne zvolených váh.

---

## 9. Singular Value Decomposition, SVD

Každú reálnu maticu možno zapísať ako

$$
W=U\Sigma V^\top.
$$

Kde:

- stĺpce $U$ sú ľavé singulárne vektory,
- stĺpce $V$ sú pravé singulárne vektory,
- $\Sigma$ obsahuje singulárne hodnoty $\sigma_1\geq\sigma_2\geq\cdots\geq0$.

Geometricky SVD rozkladá transformáciu na tri kroky:

1. otočenie vstupného priestoru pomocou $V^\top$,
2. natiahnutie jednotlivých osí pomocou $\Sigma$,
3. otočenie do výstupného priestoru pomocou $U$.

MIT kurz lineárnej algebry má samostatnú prednášku a poznámky k SVD [4].

### 9.1 Súvis SVD a Gramovej matice

Majme SVD (oblubena vec z prveho pokusu o paper)

$$
W=U\Sigma V^\top
$$

A z matice $$W$$ vieme vytvorit Gramovu maticu $$WW^\top$$, 
potom

$$
WW^\top
=U\Sigma V^\top V\Sigma^\top U^\top
=U\Sigma\Sigma^\top U^\top.
$$
:D CHAPES ZE SOM V TAKEJTO RABBITHOLE, CITIM ZE MI VYPADAVAJU VLASY

Keďže $V^\top V=I$, pravé singulárne vektory zmiznú.

Pre bežný tvar:

$$
WW^\top
=U\operatorname{diag}(\sigma_1^2,\sigma_2^2,\ldots)U^\top.
$$

To znamená:

- vlastné smery Gramovej matice sú ľavé singulárne smery $W$,
- vlastné čísla Gramovej matice sú štvorce singulárnych hodnôt.

Po trace normalizácii:

$$
C
=U\operatorname{diag}\left(
\frac{\sigma_1^2}{\sum_j\sigma_j^2},
\frac{\sigma_2^2}{\sum_j\sigma_j^2},\ldots
\right)U^\top.
$$

Toto je dôvod, prečo dokument používa názov **weighted spectrum**:

- „spectrum“ sú vlastné čísla alebo singulárne hodnoty,
- „weighted“ znamená, že hidden smery sú vážené normalizovanou energiou $\sigma_i^2/\sum_j\sigma_j^2$.

Termín `weighted spectrum` v tomto presnom použití nie je štandardný názov jednej známej metódy. Je to vlastné pomenovanie normalizovaného spektrálneho operátora, ktorý uchováva aj orientáciu singulárnych smerov.

---

# Časť II: Prečo rank-one ROME edit vytvára rank-two Gramovu zmenu

## 10. Algebraický rozvoj

ROME edit zapíšme ako

$$
W'=W+ab^\top.
$$

Gramova matica po edite je

$$
W'W'^\top
=(W+ab^\top)(W+ab^\top)^\top.
$$

Keďže

$$
(W+ab^\top)^\top=W^\top+ba^\top,
$$

dostaneme

$$
W'W'^\top
=(W+ab^\top)(W^\top+ba^\top).
$$

Roznásobením:

$$
W'W'^\top
=WW^\top+Wba^\top+ab^\top W^\top+ab^\top ba^\top.
$$

Posledný člen:

$$
ab^\top ba^\top
=a(b^\top b)a^\top
=\|b\|_2^2aa^\top.
$$

Preto

$$
\Delta G
=W'W'^\top-WW^\top
=Wba^\top+a(Wb)^\top+\|b\|_2^2aa^\top.
$$

---

## 11. Prečo má táto zmena rank najviac 2

Označme

$$
c=Wb.
$$

Potom

$$
\Delta G
=ca^\top+ac^\top+\|b\|_2^2aa^\top.
$$

Každý stĺpec jednotlivých členov je lineárnou kombináciou vektorov $a$ a $c$:

- $ca^\top$ má stĺpce v smere $c$,
- $ac^\top$ má stĺpce v smere $a$,
- $aa^\top$ má stĺpce v smere $a$.

Celý stĺpcový priestor teda leží v

$$
\operatorname{span}\{a,Wb\}.
$$

Tento priestor má najviac dva nezávislé smery, preto

$$
\operatorname{rank}(\Delta G)\leq2.
$$

Toto je presné tvrdenie pre **nenormalizovanú** Gramovu maticu.

### Kritický detail

Pre normalizované operátory

$$
C'=\frac{W'W'^\top}{\|W'\|_F^2},
\qquad
C=\frac{WW^\top}{\|W\|_F^2}
$$

už vo všeobecnosti neplatí

$$
\operatorname{rank}(C'-C)\leq2.
$$

Dôvodom je, že zmena menovateľa preškáluje celú pôvodnú Gramovu maticu. Rozdiel obsahuje aj globálny člen proporcionálny k $WW^\top$, ktorý môže mať vysoký rank.

Dokument tento problém priznáva a tvrdí iba to, že charakteristická časť editu zostáva koncentrovaná v prvých dvoch reziduálnych smeroch. To je rozumná hypotéza, ale už nie čistý algebraický dôsledok rank-one editu.

---

## 12. Malý numerický príklad

Nech

$$
W=
\begin{bmatrix}
1&0&1\\
0&1&1
\end{bmatrix},
\quad
a=
\begin{bmatrix}1\\2\end{bmatrix},
\quad
b=
\begin{bmatrix}1\\-1\\0.5\end{bmatrix}.
$$

Rank-one update je

$$
ab^\top=
\begin{bmatrix}
1&-1&0.5\\
2&-2&1
\end{bmatrix}.
$$

Teda

$$
W'=
\begin{bmatrix}
2&-1&1.5\\
2&-1&2
\end{bmatrix}.
$$

Pôvodná a editovaná Gramova matica:

$$
WW^\top=
\begin{bmatrix}
2&1\\
1&2
\end{bmatrix},
$$

$$
W'W'^\top=
\begin{bmatrix}
7.25&8\\
8&9
\end{bmatrix}.
$$

Rozdiel:

$$
\Delta G=
\begin{bmatrix}
5.25&7\\
7&7
\end{bmatrix}.
$$

V dvojrozmernom hidden priestore má tento príklad rank 2. Pri veľkom hidden rozmere by rovnaká algebra stále obmedzovala zmenu na nanajvýš dvojrozmerný podpriestor $\operatorname{span}\{a,Wb\}$.

---

# Časť III: Lokálne porovnanie vrstiev

## 13. Prečo nestačí vybrať vrstvu s najväčšou singulárnou hodnotou

Transformerové vrstvy nie sú identické. Niektoré hĺbky môžu prirodzene mať:

- väčší spektrálny gap,
- dominantnejší prvý singulárny smer,
- väčšiu normu,
- ostrejšiu zmenu geometrie.

Ak by detektor použil iba

$$
\arg\max_l \sigma_1(W_l),
$$

mohol by opakovane vyberať rovnakú architektúrne výnimočnú vrstvu bez ohľadu na to, kde bol vykonaný edit.

Preto metóda nehľadá absolútne extrémnu vrstvu. Hľadá vrstvu, ktorá je neobvyklá vzhľadom na svoje bezprostredné okolie.

---

## 14. Lokálny referenčný profil

Pre vrstvu $l$ sa definuje

$$
R_l=\frac{C_{l-1}+C_{l+1}}{2}.
$$

To je jednoduchá lineárna interpolácia medzi susednými vrstvami.

Interpretácia:

> Ak sa geometria váh mení s hĺbkou hladko, priemer susedov je približný odhad toho, ako by mala vyzerať vrstva $l$ bez lokálnej anomálie.

Následne

$$
A_l=C_l-R_l.
$$

- Ak $C_l$ približne pokračuje v susednom trende, $A_l$ je malé.
- Ak má vrstva izolovanú zmenu, $A_l$ je veľké.

Dokument nazýva $A_l$ second-order depth residual. Je to analógia s diskrétnou druhou deriváciou:

$$
C_l-\frac{C_{l-1}+C_{l+1}}{2}
=-\frac12(C_{l-1}-2C_l+C_{l+1}).
$$

Až na konštantný faktor ide o diskrétnu krivosť profilu cez hĺbku.

### Čo je na tom heuristické

Tvrdenie, že nepoškodené transformerové vrstvy majú lokálne hladkú spektrálnu geometriu, nie je všeobecná veta o transformeroch. Je to empirický predpoklad detektora.

Môže zlyhať, keď:

- vrstva prirodzene tvorí ostrú architektúrnu hranicu,
- susedné vrstvy majú špeciálne roly,
- model má periodickú alebo nepravidelnú hĺbkovú štruktúru,
- edit je na okraji siete,
- viac vrstiev bolo zmenených naraz.

---

## 15. Prečo edit ovplyvní aj susedné reziduá

Predpokladajme, že iba $C_k$ dostane perturbáciu $D$:

$$
C_k' = C_k+D.
$$

Potom:

### Reziduum v strede

$$
A_k'=C_k+D-\frac{C_{k-1}+C_{k+1}}2
=A_k+D.
$$

Teda

$$
\delta A_k=D.
$$

### Reziduum vľavo

$$
A_{k-1}'
=C_{k-1}-\frac{C_{k-2}+C_k+D}{2}
=A_{k-1}-\frac12D.
$$

Teda

$$
\delta A_{k-1}=-\frac12D.
$$

### Reziduum vpravo

Analogicky

$$
\delta A_{k+1}=-\frac12D.
$$

Vzniká charakteristický trojvrstvový podpis

$$
\left(-\frac12,1,-\frac12\right).
$$

Aktuálny detektor používa normu každej vrstvy samostatne, takže zahodí znamienka. To vysvetľuje, prečo môže niekedy vybrať susednú vrstvu. Návrh v dokumente, ktorý explicitne páruje trojvrstvový reziduálny podpis, je matematicky motivované zlepšenie.

---

# Časť IV: Extrakcia dvojrozmerného podpriestoru

## 16. Prečo sa vyberajú dva smery

Matica $A_l$ môže mať rozmer napríklad $4096\times4096$. Detektor však očakáva, že ROME-like signál bude koncentrovaný približne v dvojrozmernom podpriestore.

Preto nájde dva dominantné singulárne smery $A_l$:

$$
U_l\in\mathbb{R}^{h\times2}.
$$

Stĺpce $U_l$ tvoria ortonormálnu bázu dvojrozmerného kandidátneho podpriestoru.

### Prečo singulárne vektory a nie vlastné vektory

$A_l$ je symetrická matica, preto by bolo možné použiť vlastný rozklad. Pri symetrickej matici:

- singulárne hodnoty sú absolútne hodnoty vlastných čísel,
- singulárne vektory zodpovedajú vlastným smerom.

SVD teda vyberie smery s najväčšou zmenou podľa absolútnej veľkosti, bez ohľadu na to, či je zmena kladná alebo záporná.

Toto je vhodné, pretože lokálny reziduálny podpis môže obsahovať kladné aj záporné módy.

### Dôležitý rozdiel

„Dva smery“ nie sú dve konkrétne neuróny. Sú to dve lineárne kombinácie hidden koordinátov.

---

## 17. Projekcia do podpriestoru

Detektor vytvorí

$$
B_l=U_l^\top A_lU_l.
$$

Rozmery:

$$
U_l^\top:2\times h,
\qquad
A_l:h\times h,
\qquad
U_l:h\times2,
$$

preto

$$
B_l\in\mathbb{R}^{2\times2}.
$$

$B_l$ je komprimovaná verzia rezidua. Opisuje, čo sa deje s $A_l$ iba v dvoch vybraných smeroch.

Podobne

$$
G_l=U_l^\top R_lU_l
$$

meria energiu susedného referenčného profilu v tých istých smeroch.

To je zásadné. Detektor neporovnáva zmenu v jednom priestore s pozadím v inom priestore. Obe matice sú premietnuté do rovnakej bázy $U_l$.

---

# Časť V: Whitening

## 18. Čo je whitening všeobecne

Whitening je transformácia, ktorá preškáluje a prípadne otočí súradnice tak, aby mala referenčná kovariančná alebo energetická matica jednotkový tvar.

Ak je $G$ pozitívne definitná a má vlastný rozklad

$$
G=Q\Lambda Q^\top,
$$

potom

$$
G^{-1/2}=Q\Lambda^{-1/2}Q^\top,
$$

kde

$$
\Lambda^{-1/2}
=\operatorname{diag}\left(
\frac1{\sqrt{\lambda_1}},
\frac1{\sqrt{\lambda_2}},\ldots
\right).
$$

Platí

$$
G^{-1/2}GG^{-1/2}=I.
$$

Po tejto transformácii sa referenčná geometria $G$ javí ako jednotková a izotropná.

Kessy, Lewin a Strimmer opisujú whitening ako lineárnu transformáciu, ktorá mapuje kovarianciu na jednotkovú maticu [5].

---

## 19. Intuitívny príklad whitening

Predstavme si dva smery:

- v prvom má pozadie energiu 100,
- v druhom má pozadie energiu 1.

Teda približne

$$
G=
\begin{bmatrix}
100&0\\
0&1
\end{bmatrix}.
$$

Nech zmena je

$$
B=
\begin{bmatrix}
10&0\\
0&1
\end{bmatrix}.
$$

Bez normalizácie sa prvý smer zdá desaťkrát väčší.

Whitening matica je

$$
G^{-1/2}=
\begin{bmatrix}
1/10&0\\
0&1
\end{bmatrix}.
$$

Po whiteningu:

$$
E=G^{-1/2}BG^{-1/2}
=
\begin{bmatrix}
0.1&0\\
0&1
\end{bmatrix}.
$$

Relatívne k pozadiu je druhá zmena oveľa nezvyčajnejšia.

Toto presne vystihuje motiváciu detektora:

- veľká zmena v prirodzene silnom smere nemusí byť podozrivá,
- menšia zmena v smere, ktorý susedia takmer nepoužívajú, môže byť veľmi podozrivá.

---

## 20. Whitening v detektore

Detektor počíta

$$
E_l=G_l^{-1/2}B_lG_l^{-1/2}.
$$

Kde:

- $B_l$ je pozorovaná zmena,
- $G_l$ je lokálna referenčná energia,
- $E_l$ je relatívna zmena po odstránení mierky a korelácií pozadia.

Názov **affine-relative whitening** nie je všeobecne ustálený názov tejto presnej operácie. Štandardné matematické pojmy sú:

- whitening,
- congruence transformácia,
- redukcia generalizovaného eigenvalue problému na obyčajný eigenvalue problém.

---

## 21. Súvis s generalizovanými vlastnými číslami

Generalizovaný eigenvalue problém má tvar

$$
Bv=\lambda Gv.
$$

Hľadá smery, v ktorých je zmena $B$ veľká relatívne k metrike alebo pozadiu $G$.

Ak definujeme

$$
u=G^{1/2}v,
$$

potom možno problém prepísať na obyčajný eigenvalue problém matice

$$
G^{-1/2}BG^{-1/2}.
$$

Vlastné čísla $E_l$ preto hovoria, aká veľká je zmena v jednotlivých módoch v pomere k lokálnej podpore.

Univerzitné poznámky Harvey Mudd College ukazujú rovnaký whitening krok pri riešení generalizovaného eigenvalue problému [6].

---

## 22. Numerická stabilizácia `EPS`

Ak má $G_l$ veľmi malé vlastné číslo, potom

$$
\frac1{\sqrt{\lambda}}
$$

môže byť extrémne veľké. Malý numerický šum by sa potom neúmerne zosilnil.

Preto implementácia nahrádza

$$
\lambda_i\leftarrow\max(\lambda_i,10^{-10}).
$$

Toto je regularizácia numerickej inverzie. Nie je to threshold na rozhodnutie, či je model editovaný.

Napriek tomu hodnota `EPS` ovplyvňuje maximálne možné zosilnenie slabo podporovaných smerov. Je teda numerický hyperparameter, aj keď nie je štatistický klasifikačný prah.

---

# Časť VI: Finálne skóre

## 23. Prečo Frobeniova norma $E_l$

Finálne skóre je

$$
s_l=\|E_l\|_F.
$$

Keďže $E_l$ je iba $2\times2$, jeho Frobeniova norma je

$$
\|E_l\|_F
=
\sqrt{E_{11}^2+E_{12}^2+E_{21}^2+E_{22}^2}.
$$

Ak je $E_l$ symetrická s vlastnými číslami $\lambda_1,\lambda_2$, potom

$$
\|E_l\|_F
=
\sqrt{\lambda_1^2+\lambda_2^2}.
$$

Skóre teda agreguje oba relatívne módy.

Alternatívy by boli:

- $\max(|\lambda_1|,|\lambda_2|)$, iba najsilnejší mód,
- $|\lambda_1|+|\lambda_2|$, nukleárna norma,
- $\lambda_1+\lambda_2$, ktorá by mohla rušiť kladnú a zápornú zmenu.

Frobeniova norma je rozumná voľba, pretože:

- ignoruje znamienko,
- využíva oba očakávané smery,
- nemení sa pri otočení bázy v rámci dvojrozmerného podpriestoru.

Nie je však algebraicky jediná možná voľba. Je to dizajnové rozhodnutie detektora.

---

## 24. Argmax cez vrstvy

Nakoniec:

$$
\hat l=\operatorname*{arg\,max}_{l\in\mathcal L}s_l.
$$

To znamená:

1. vypočítaj jedno skóre pre každú povolenú vrstvu,
2. nájdi najväčšie skóre,
3. vráť index tejto vrstvy.

Margin medzi prvým a druhým skóre:

$$
\text{margin}=s_{(1)}-s_{(2)}
$$

môže indikovať neistotu lokalizácie. Sám osebe však nie je kalibrovanou pravdepodobnosťou ani dôkazom prítomnosti editu.

---

# Časť VII: Invariancie

## 25. Storage-transpose invariance

Rôzne knižnice môžu rovnakú lineárnu mapu ukladať ako $W$ alebo $W^\top$.

Detektor vyberá Gramovu maticu na hidden strane:

- ak hidden os tvoria riadky, použije $WW^\top$,
- ak hidden os tvoria stĺpce, použije $W^\top W$.

Pri správnej identifikácii hidden osi preto dostane rovnaký hidden-space operátor nezávisle od storage konvencie.

---

## 26. Global-scale invariance

Pre ľubovoľné $\alpha\neq0$:

$$
C(\alpha W)
=
\frac{\alpha W(\alpha W)^\top}{\|\alpha W\|_F^2}
=
C(W).
$$

Celková mierka váh sa odstráni.

---

## 27. Zmena hidden bázy

Nech sa všetky hidden reprezentácie otočia ortogonálnou maticou $Q$:

$$
W\mapsto QW.
$$

Potom

$$
C\mapsto QCQ^\top.
$$

Všetky objekty sa otočia konzistentne. Vlastné čísla a Frobeniova norma sa pri ortogonálnej zmene bázy nemenia.

Detektor teda nezávisí od poradia alebo konkrétneho pomenovania hidden súradníc.

### Presný názov vlastnosti

Toto nie je úplná invariantnosť matice $C$, pretože $C$ sa zmení na $QCQ^\top$. Správnejšie je hovoriť o **kovariancii reprezentácie** a **invariantnosti finálneho skalárneho skóre**.

---

# Časť VIII: Čo je štandardná matematika a čo je nový návrh

## 28. Štandardné časti

Nasledujúce prvky sú klasická lineárna algebra:

- vonkajší súčin a rank-one matica,
- Gramova matica,
- pozitívna semidefinitnosť,
- trace a Frobeniova norma,
- SVD,
- projekcia do podpriestoru,
- matrix inverse square root,
- whitening,
- generalizované vlastné čísla,
- Frobeniova norma symetrickej matice.

Tieto časti možno študovať nezávisle v učebniciach a univerzitných materiáloch.

## 29. Vlastné alebo heuristické časti detektora

Nasledujúce rozhodnutia sú špecifické pre túto metódu:

1. použiť trace-one hidden Gram ako profil vrstvy,
2. odhadovať normálnu vrstvu priemerom dvoch susedov,
3. vybrať presne dva reziduálne smery aj po trace normalizácii,
4. whitenovať reziduum pomocou susednej podpory v tom istom podpriestore,
5. agregovať dva módy Frobeniovou normou,
6. trimovať prvých a posledných päť vrstiev,
7. použiť maximum skóre ako lokalizáciu.

Tieto kroky môžu byť dobre motivované, ale ich kvalitu musí potvrdiť experimentálna validácia.

---

# Časť IX: Kritické hodnotenie metódy

## 30. Silné stránky

### 30.1 Nepotrebuje čistý checkpoint

To je podstatne ťažší a praktickejší threat model ako obyčajné odčítanie váh.

### 30.2 Využíva štruktúru ROME

Metóda nehľadá ľubovoľnú anomáliu. Je motivovaná tým, že rank-one zmena váh vytvára nanajvýš rank-two zmenu nenormalizovanej hidden Gramovej matice.

### 30.3 Porovnáva geometricky zarovnané objekty

Hidden-space Gram rieši problém, že intermediate neuróny medzi vrstvami nemajú prirodzenú korešpondenciu.

### 30.4 Relatívne skóre potláča architektúrne dominantné smery

Whitening je lepšie odôvodnený než ručne zvolená zmes nesúvisiacich feature skóre.

### 30.5 Má jasné invariancie

Odstránenie celkovej mierky a storage-transpose problému znižuje potrebu model-family pravidiel.

---

## 31. Slabé stránky a otvorené otázky

### 31.1 Nie je to binárny detektor

Bez čistého null rozdelenia môže vysoké maximum vzniknúť aj na nepoškodenom modeli.

### 31.2 Trace normalizácia narúša presný rank-two argument

Rank-two tvrdenie je presné pre $W'W'^\top-WW^\top$, nie pre rozdiel dvoch samostatne trace-normalizovaných operátorov.

### 31.3 Hladkosť cez hĺbku je empirický predpoklad

Prirodzená ostrá zmena medzi vrstvami môže vyzerať ako edit.

### 31.4 Susedné reziduá nie sú nezávislé

Jeden edit vytvorí stredný peak a dve záporné ozveny. Samostatné normovanie vrstiev zahodí tento podpis.

### 31.5 Trimovanie vytvára slepú oblasť

Edit v prvých alebo posledných piatich vrstvách nemožno nájsť pri defaultnom nastavení.

### 31.6 Hidden os podľa menšieho rozmeru je iba konvencia

Pre netypickú architektúru sa môže pomýliť.

### 31.7 Plná Gramova matica je drahá

Pamäť rastie ako $O(h^2)$. Pri veľkých hidden rozmeroch je vhodná implicitná alebo skicovaná implementácia.

### 31.8 Proveniencia nie je identifikovateľná iba z váh

Ak iná metóda vytvorí rovnaký rank-one update v rovnakej vrstve, finálne váhy neobsahujú informáciu o tom, ktorý program ho vytvoril. Technicky presnejší label je:

> detegovaný lokalizovaný ROME-like rank-one edit

nie:

> dokázané použitie konkrétnej implementácie ROME.

---

# Časť X: Ako čítať finálny vzorec

Finálne skóre je

$$
s_l=
\left\|
G_l^{-1/2}
U_l^\top(C_l-R_l)U_l
G_l^{-1/2}
\right\|_F.
$$

Rozoberme ho zvnútra smerom von.

### Krok 1

$$
C_l-R_l
$$

Odčítaj očakávaný lokálny profil od skutočného profilu vrstvy.

### Krok 2

$$
U_l^\top(C_l-R_l)U_l
$$

Ponechaj iba dva smery s najsilnejšou anomáliou.

### Krok 3

$$
G_l^{-1/2}[\cdot]G_l^{-1/2}
$$

Prepočítaj anomáliu vzhľadom na normálnu susednú energiu v rovnakých smeroch.

### Krok 4

$$
\|\cdot\|_F
$$

Zlúč oba relatívne anomálne módy do jedného nezáporného čísla.

Najjednoduchší slovný preklad:

> Skóre meria, aká veľká je dvojrozmerná lokálna zmena geometrie vrstvy v porovnaní s tým, ako silno jej susedia bežne podporujú presne tie isté smery.

---

# Časť XI: Odporúčané poradie štúdia

## 32. Minimum potrebné na pochopenie dokumentu

### Krok 1: Matice, transpozícia, vnútorný a vonkajší súčin

Prejdi si základné kapitoly o maticiach a matrix multiplication v Boydovej učebnici [2].

Potrebné pojmy:

- $Wx$,
- $W^\top$,
- $x^\top y$,
- $xy^\top$,
- rozmery matíc.

### Krok 2: Rank a podpriestory

Musíš rozumieť, prečo rank-one update zasahuje iba jeden nový smer a prečo jeho Gramova stopa leží najviac v dvoch smeroch.

### Krok 3: Gramova matica a PSD

Zameraj sa na identity:

$$
G=W^\top W,
\qquad
x^\top Gx=\|Wx\|^2.
$$

Boydova učebnica a MIT PSD materiály sú vhodné zdroje [2,3].

### Krok 4: Frobeniova norma a trace

Pochop:

$$
\|W\|_F^2=\operatorname{tr}(WW^\top).
$$

Bez toho nebude jasné, prečo normalizácia vytvorí trace-one operátor.

### Krok 5: SVD

Pochop:

$$
W=U\Sigma V^\top,
\qquad
WW^\top=U\Sigma^2U^\top.
$$

Toto je jadro pojmu „weighted spectrum“ [4].

### Krok 6: Whitening

Pochop vlastný rozklad PSD matice a význam

$$
G^{-1/2}GG^{-1/2}=I.
$$

Potom bude jasné, prečo sa zmena delí lokálnou podporou [5].

### Krok 7: Generalizovaný eigenvalue problém

Pochop vzťah

$$
Bv=\lambda Gv
$$

a prechod na

$$
G^{-1/2}BG^{-1/2}.
$$

Tým dostaneš presný význam „relatívnych módov“ [6].

### Krok 8: ROME článok

Až potom čítaj ROME rovnicu pre rank-one edit MLP projection [1].

---

# Časť XII: Zdroje

## Primárne a univerzitné zdroje

[1] Kevin Meng, David Bau, Alex Andonian, Yonatan Belinkov. **Locating and Editing Factual Associations in GPT.** NeurIPS 2022.  
https://proceedings.neurips.cc/paper_files/paper/2022/hash/6f1d43d5a82a37e89b0665b33bf3a182-Abstract-Conference.html

Najrelevantnejšie: sekcia 3.1 a rovnica rank-one update MLP projekcie.

[2] Stephen Boyd, Lieven Vandenberghe. **Introduction to Applied Linear Algebra: Vectors, Matrices, and Least Squares.** Cambridge University Press, voľne dostupná autorská verzia.  
https://web.stanford.edu/~boyd/vmls/

Najrelevantnejšie:

- kapitola o maticiach a matrix multiplication,
- Frobeniova norma,
- Gramova matica,
- vnútorné a vonkajšie súčiny.

[3] Gilbert Strang. **Positive Definite and Semidefinite Matrices.** MIT OpenCourseWare.  
https://ocw.mit.edu/courses/18-065-matrix-methods-in-data-analysis-signal-processing-and-machine-learning-spring-2018/resources/lecture-5-positive-definite-and-semidefinite-matrices/

Najrelevantnejšie: význam $x^\top Cx\geq0$, faktorizácie typu $A^\top A$, nezáporné vlastné čísla.

[4] Gilbert Strang. **Singular Value Decomposition.** MIT OpenCourseWare, Linear Algebra 18.06SC.  
https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/resources/mit18_06scf11_ses3-5sum/

Najrelevantnejšie: rozklad $W=U\Sigma V^\top$, singulárne smery, nízkohodnostné aproximácie.

[5] Agnan Kessy, Alex Lewin, Korbinian Strimmer. **Optimal Whitening and Decorrelation.** The American Statistician 72(4), 2018.  
https://arxiv.org/abs/1512.00809

Najrelevantnejšie: whitening ako transformácia kovariancie na identitu a použitie inverse square root matice.

[6] Ruye Wang. **Generalized Eigenvalue Problem.** Harvey Mudd College lecture notes.  
https://pages.hmc.edu/ruye/e161/lectures/algebra/node7.html

Najrelevantnejšie: whitening generalizovaného eigenvalue problému a Rayleighov podiel.

---

# Záver

Matematické jadro detektora je rozumné:

1. ROME mení váhu rank-one vonkajším súčinom.
2. Takáto zmena vytvorí v nenormalizovanej hidden Gramovej matici perturbáciu s rankom najviac 2.
3. Hidden Gram umožňuje porovnávať vrstvy v spoločnom residual-stream priestore.
4. Trace normalizácia odstráni absolútnu mierku váh.
5. Lokálny reziduál odfiltruje hladký trend cez hĺbku.
6. Dvojrozmerná projekcia hľadá očakávanú nízkohodnostnú stopu.
7. Whitening meria zmenu relatívne k tomu, čo susedné vrstvy v tých smeroch normálne podporujú.
8. Frobeniova norma vytvorí jedno skóre pre každú vrstvu.

Najdôležitejšie je oddeliť presnú algebru od heuristiky. Rank-two tvrdenie je presné pred trace normalizáciou. Lokálna hladkosť vrstiev, dominancia prvých dvoch smerov po normalizácii a použitie susedného whitening sú návrhové predpoklady, ktoré musia byť overené na čistých modeloch, rôznych architektúrach a confounderoch.
