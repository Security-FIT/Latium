#!/usr/bin/env bash

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESULTS_ROOT="${RESULTS_ROOT:-$ROOT/rome-detector-results-latest/analysis_out/metacentrum/rome-detectors}"
DEST="${DEST:-$ROOT/analysis_out/legacy-spectral-comparison/fleet-failures}"
REMOTE="${REMOTE:-olexamatej@skirit.metacentrum.cz}"
REMOTE_ROOT="${REMOTE_ROOT:-Latium-rome-detectors/analysis_out/metacentrum/rome-detectors}"
THRESHOLD="${THRESHOLD:-0.9}"

if [[ ! -d "$RESULTS_ROOT" ]]; then
  echo "Result summaries not found: $RESULTS_ROOT" >&2
  exit 1
fi

runs=()
while IFS= read -r summary; do
  detector="$(jq -r '.detectors | keys[] | select(startswith("legacy-spectral-confirmation"))' "$summary")"
  [[ -n "$detector" ]] || continue

  if jq -e --arg detector "$detector" --argjson threshold "$THRESHOLD" \
    '.detectors[$detector].accuracy < $threshold' "$summary" >/dev/null
  then
    runs+=("$(basename "$(jq -r '.run_root' "$summary")")")
  fi
done < <(find "$RESULTS_ROOT" -mindepth 2 -maxdepth 2 -name rome-detector-job-summary.json -type f | sort)

if (( ${#runs[@]} == 0 )); then
  echo "No failed legacy-spectral runs found below accuracy $THRESHOLD." >&2
  exit 1
fi

mkdir -p "$DEST"
printf 'Fetching %d failed legacy-spectral runs into %s:\n' "${#runs[@]}" "$DEST"
printf '  %s\n' "${runs[@]}"

if [[ "${DRY_RUN:-0}" == "1" ]]; then
  exit 0
fi

remote_paths=()
for run in "${runs[@]}"; do
  remote_paths+=("$run/graphs/legacy-detector-signals")
done
printf -v quoted_paths ' %q' "${remote_paths[@]}"

# The command is intentionally assembled from the validated run directory names above.
# shellcheck disable=SC2029
ssh "$REMOTE" \
  "cd '$REMOTE_ROOT' && tar -cf -$quoted_paths" \
  | tar -xf - -C "$DEST"

echo
echo "Downloaded graph counts:"
for run in "${runs[@]}"; do
  graph_dir="$DEST/$run/graphs/legacy-detector-signals"
  count="$(find "$graph_dir" -maxdepth 1 -name '*.png' -type f | wc -l)"
  printf '  %-75s %s PNGs\n' "$run" "$count"
done

echo
echo "Graphs are under: $DEST"
