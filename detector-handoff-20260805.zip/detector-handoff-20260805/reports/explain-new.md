# Ako funguje aktuálny `weighted-spectrum` ROME lokalizátor

## Aktualizované vysvetlenie po zjednodušení na `diagonal_relative`

Tento dokument nahrádza algoritmický opis v `explain.md`. Starý dokument stále
obsahuje užitočnú lineárnu algebru, ale vysvetľuje pôvodný M3 postup s plným
2x2 whiteningom. Produkčný kód od schémy `rome-detector-minimal-v3` používa
jednoduchšie skóre `diagonal_relative`.

Legenda:

- **POUŽÍVA SA**: súčasť aktuálneho produkčného lokalizátora;
- **ZMENENÉ**: myšlienka zostala, ale výpočet alebo názov sa zmenil;
- ~~NEPOUŽÍVA SA~~: historická alebo experimentálna časť, ktorá nie je v
  aktuálnom kontrakte.

---

## 1. Čo komponent robí

Komponent dostane editovateľné MLP output/down-projection váhy z **jedného
podozrivého checkpointu**. Pre vrstvy vypočíta profil lokálnej nízkohodnostnej
anomálie a z povolených vrstiev vyberie vrstvu s najvyšším skóre.

Verejná interpretácia je:

> Ak checkpoint obsahuje jeden lokalizovaný ROME-compatible nízkohodnostný
> zásah, ktorá MLP projekčná vrstva je najsilnejší kandidát?

Nie:

> ~~Bol checkpoint vytvorený programom ROME: áno alebo nie?~~

Aktuálny komponent je **lokalizátor**, nie binárny detektor proveniencie.
Neobsahuje produkčný prah a nevracia boolean `is_rome`.

---

## 2. Aktuálna metóda v jednej vete

Pre každú vnútornú vrstvu lokalizátor vytvorí normalizovanú Gramovu maticu v
hidden priestore, odpočíta priemer dvoch susedov, nájde dva dominantné
singulárne smery rezidua, vydelí každú singulárnu hodnotu podporou susedov v
tom istom smere a z povolených vrstiev vyberie najvyššie výsledné skóre.

Aktuálny reťazec je:

```text
W_l
  -> C_l                         normalizovaný hidden Gram
  -> N_l                         priemer dvoch susedov
  -> R_l = C_l - N_l             lokálne reziduum
  -> (u_1, sigma_1), (u_2, sigma_2)
  -> b_i = u_i^T N_l u_i         dve skalárne podpory
  -> diagonal_relative(l)
  -> trim + deterministický argmax
```

Historický reťazec bol:

> ~~`W_l -> C_l -> R_l -> U_l -> dve 2x2 matice -> inverse square root ->`~~
> ~~`obojstranný whitening -> M3 Frobeniovo skóre`~~

---

## 3. Presný produkčný vzorec

Nech `W_l` je editovateľná projekčná váha vrstvy `l`.

### Krok 1: normalizovaný hidden Gram

Menšia os obdĺžnikovej projekcie sa považuje za spoločnú hidden os:

$$
C_l =
\begin{cases}
\dfrac{W_lW_l^\top}{\lVert W_l\rVert_F^2},
& \text{ak } \operatorname{rows}(W_l)\leq\operatorname{cols}(W_l),\\[1.2ex]
\dfrac{W_l^\top W_l}{\lVert W_l\rVert_F^2},
& \text{inak.}
\end{cases}
$$

Matica $C_l$:

- je symetrická a pozitívne semidefinitná;
- žije na menšej, typicky hidden osi;
- má stopu približne 1;
- nemení sa pri násobení celej váhy nenulovým skalárom;
- pre bežnú obdĺžnikovú projekciu je invariantná voči spôsobu uloženia
  `W` verzus `W.T`.

Implementácia odmietne maticu, ktorá nie je dvojrozmerná, obsahuje `NaN` alebo
`Inf`, alebo je numericky nulová.

### Krok 2: lokálna referencia a reziduum

Pre vnútornú vrstvu sa použijú bezprostrední susedia v zoradenom zozname
projekčných vrstiev:

$$
N_l = \frac{C_{l-1}+C_{l+1}}{2},
$$

$$
R_l = C_l-N_l.
$$

V tomto dokumente:

- $N_l$ je **neighbor reference**;
- $R_l$ je **residual**.

Starý `explain.md` používal na rovnaké objekty názvy $R_l$ pre referenciu a
$A_l$ pre reziduum. To bola iba odlišná notácia:

> ~~staré: `R_l = neighbor reference`, `A_l = residual`~~

> **aktuálne: `N_l = neighbor reference`, `R_l = residual`**

Pokusom je odstrániť hladký trend cez hĺbku. Izolovaná zmena v jednej vrstve
má v rezidue zostať výraznejšia než prirodzená pomalá zmena susedných vrstiev.

### Krok 3: dva dominantné smery

Z $R_l$ sa deterministicky seedovaným low-rank SVD odhadnú dva dominantné ľavé
singulárne smery:

$$
R_l \approx U_l\Sigma_lV_l^\top,
\qquad
U_l=[u_1,u_2],
\qquad
\Sigma_l=\operatorname{diag}(\sigma_1,\sigma_2).
$$

Produkcia používa `torch.svd_lowrank` cez helper `gpu_svd_topk`, `k=2`,
`niter=4` a seed odvodený od čísla vrstvy. Nie je to plný SVD všetkých smerov.

Prečo dva smery: rank-one zmena váhy vytvára v **nenormalizovanom** hidden
Grame zmenu s rankom najviac dva. Po trace normalizácii už tento rankový limit
neplatí presne, ale top-2 koncentrácia zostáva empirickou hypotézou
lokalizátora.

### Krok 4: dve skalárne podpory

V každom SVD smere sa zmeria energia susednej referencie:

$$
b_i=u_i^\top N_lu_i,
\qquad i\in\{1,2\}.
$$

To sú dve čísla. Aktuálny výpočet nepoužíva mimo-diagonálne väzby medzi
$u_1$ a $u_2$.

Pre numerickú stabilitu sa podpora zdola ohraničí:

$$
\widetilde b_i=\max(b_i,\tau_l),
$$

kde zjednodušene

$$
\tau_l =
\operatorname{eps}(\text{dtype})\,
\max(1,h)\,
\max\left(
  \lVert U_l^\top N_lU_l\rVert_F,
  \lVert R_l\rVert_F,
  \operatorname{tiny}(\text{dtype})
\right).
$$

Toto nie je prah na rozhodnutie ROME áno/nie. Je to ochrana pred delením
zanedbateľnou podporou.

### Krok 5: `diagonal_relative` skóre

Skóre vrstvy je:

$$
s_l =
\sqrt{
  \left(\frac{\sigma_1}{\widetilde b_1}\right)^2+
  \left(\frac{\sigma_2}{\widetilde b_2}\right)^2
}.
$$

V artefakte sa toto číslo volá:

```text
diagonal_relative
```

Interpretácia jedného člena:

$$
\frac{\sigma_i}{\widetilde b_i}
=
\frac{\text{veľkosť lokálnej zmeny v smere }u_i}
     {\text{bežná susedná podpora smeru }u_i}.
$$

Veľká absolútna zmena v prirodzene silnom smere sa preto potlačí. Menšia zmena
v smere so slabou susednou podporou sa zvýrazní.

---

## 4. Čo sa z pôvodného M3 odstránilo

Pôvodný M3 najprv vytvoril celé 2x2 projekcie:

> ~~$A_l=U_l^\top R_lU_l$~~

> ~~$B_l=U_l^\top N_lU_l$~~

Potom diagonalizoval podpornú maticu a vytvoril jej inverznú odmocninu:

> ~~$B_l=Q_l\Lambda_lQ_l^\top$~~

> ~~$B_l^{-1/2}=Q_l\Lambda_l^{-1/2}Q_l^\top$~~

Nakoniec robil obojstranný whitening a Frobeniovu normu:

> ~~$E_l=B_l^{-1/2}A_lB_l^{-1/2}$~~

> ~~$s_l^{M3}=\lVert E_l\rVert_F$~~

V aktuálnom produkčnom kóde sa teda **nepoužíva**:

- ~~eigendecomposition 2x2 podpornej matice;~~
- ~~rotácia podpriestoru podľa jej vlastných vektorov;~~
- ~~maticová inverzná odmocnina;~~
- ~~obojstranný 2x2 whitening;~~
- ~~mimo-diagonálna podporná väzba medzi dvoma SVD smermi.~~

Náhradou sú dve samostatné skalárne delenia
$\sigma_i/\widetilde b_i$.

### Čo sa zachovalo

- **hidden-Gram geometria**;
- **normalizácia Frobeniovou normou**;
- **priemer dvoch susedov**;
- **lokálne reziduum**;
- **dva dominantné SVD smery**;
- **normalizácia zmeny susednou podporou**;
- **jedno nezáporné skóre na vrstvu**;
- **výber vrstvy pomocou deterministického argmaxu**.

Zjednodušenie je najmä matematické a implementačné. Výpočet Gramových matíc a
top-2 SVD naďalej dominuje runtime; odstránenie malých 2x2 operácií neprináša
veľké celkové zrýchlenie.

---

## 5. Ktoré vrstvy môžu vyhrať

Skóre sa zachytí pre každú vnútornú vrstvu, teda pre všetky vrstvy okrem dvoch
endpointov. Endpoint nemá dvoch susedov a jeho reziduum sa preto nevypočíta.

Pri finálnom výbere sa navyše použije všeobecný 10-percentný trim. Pre `n`
zoradených projekčných vrstiev:

$$
t=\lfloor0.10n\rfloor,
$$

pričom začiatok a koniec povoleného intervalu zároveň musia vylúčiť endpointy.
Ekvivalent implementácie je:

```text
start = max(1, floor(0.10 * n))
stop  = min(n - 1, n - floor(0.10 * n))
eligible = layers[start:stop]
```

Príklad pre 20 vrstiev očíslovaných `0..19`:

```text
skóre uložené:    1..18
eligible vrstvy:  2..17
excluded vrstvy:  0, 1, 18, 19
```

Finálny výber je:

$$
l^\star=\arg\max_{l\in\mathcal E}s_l,
$$

kde $\mathcal E$ je množina eligible vrstiev.

Pri presnej zhode skóre vyhrá vrstva s nižším číslom. Ak nie je eligible žiadna
vrstva, `selected_layer` je `null`.

---

## 6. Čo lokalizátor vracia

Schéma je:

```text
rome-detector-minimal-v3
```

Konceptuálny výsledok:

```json
{
  "schema_version": "rome-detector-minimal-v3",
  "localization": {
    "eligible_layers": [1, 2, 3, 4],
    "excluded_layers": [0, 5],
    "layer_scores": {
      "1": 0.72,
      "2": 1.04,
      "3": 3.81,
      "4": 0.93
    },
    "selected_layer": 3,
    "margin": 2.77
  }
}
```

`margin` je rozdiel medzi najvyšším a druhým najvyšším eligible skóre:

$$
\operatorname{margin}=s_{(1)}-s_{(2)}.
$$

Margin sa vracia ako opis profilu. Produkcia z neho nerobí boolean verdict.

Všimnite si, že `layer_scores` môže obsahovať aj vnútorné vrstvy vyradené
10-percentným trimom. Trim určuje výber, nie to, či sa vnútorné skóre vôbec
vypočíta.

---

## 7. Prečo rank-one edit motivuje top-2 Gram signál

ROME-like zmenu váhy zapíšme:

$$
W'=W+ab^\top.
$$

Pre nenormalizovaný hidden Gram:

$$
\begin{aligned}
W'W'^\top-WW^\top
&=Wba^\top+ab^\top W^\top+\lVert b\rVert_2^2aa^\top.
\end{aligned}
$$

Stĺpcový priestor tejto zmeny leží v:

$$
\operatorname{span}\{a,Wb\}.
$$

Preto:

$$
\operatorname{rank}(W'W'^\top-WW^\top)\leq2.
$$

Toto je presný algebraický dôvod, prečo sa skúmajú dva smery.

Po normalizácii:

$$
C'=\frac{W'W'^\top}{\lVert W'\rVert_F^2},
\qquad
C=\frac{WW^\top}{\lVert W\rVert_F^2},
$$

už rozdiel $C'-C$ nemusí mať rank najviac dva, pretože zmena menovateľa
preškáluje celý pôvodný Gram. Tvrdenie, že charakteristická časť zostane
koncentrovaná v top-2 reziduálnych smeroch, je empirická hypotéza, nie
univerzálna veta.

---

## 8. Prečo sa používajú susedia

Absolútne spektrálne extrémy často patria prirodzene výnimočným vrstvám
architektúry. Surové pravidlo typu

> ~~`vyber vrstvu s najväčšou singulárnou hodnotou W_l`~~

môže stále vyberať rovnaký natívny peak bez ohľadu na edit.

Lokálne reziduum:

$$
R_l=C_l-\frac{C_{l-1}+C_{l+1}}2
$$

je až na konštantný faktor diskrétna druhá derivácia cez hĺbku. Potláča hladký
trend a zvýrazňuje ostré lokálne odchýlky.

To však predpokladá, že normálna hidden-Gram geometria sa medzi susednými
vrstvami mení dostatočne hladko. Predpoklad môže zlyhať pri:

- prirodzených architektúrnych hraniciach;
- špeciálnej úlohe konkrétnej vrstvy;
- nepravidelnej hĺbkovej štruktúre;
- edite blízko okraja;
- zmenách vo viacerých vrstvách.

---

## 9. Čo aktuálny lokalizátor nepoužíva

### Vstupy, ktoré nie sú potrebné

- ~~čistý referenčný checkpoint;~~
- ~~párové odčítanie `suspect - clean`;~~
- ~~prompt, subject, target alebo case ID;~~
- ~~informácia o skutočne editovanej vrstve;~~
- ~~causal tracing;~~
- ~~ROME covariance alebo second moment;~~
- ~~názov modelu ako feature;~~
- ~~model-family vetva;~~
- ~~prah špecifický pre rodinu modelov.~~

### Odstránené feature a rozhodovacie cesty

- ~~M0, M1 a M2;~~
- ~~M3 full whitening ako produkčné skóre;~~
- ~~`rank2_energy` multiplier;~~
- ~~bilateral coherence a balance;~~
- ~~morphology produkty a `log1p`;~~
- ~~B0 s čistou referenciou;~~
- ~~B1 a B2 blind boolean pravidlá;~~
- ~~`is_rome_like`;~~
- ~~default blind threshold;~~
- ~~produkčný robust-peak, global-prominence alebo local-prominence cutoff.~~

Tieto položky môžu existovať v historických reportoch alebo Git histórii, ale
nie sú súčasťou aktívneho `rome-detector-minimal-v3` kontraktu.

---

## 10. Čo ukázalo priame zjednodušovacie porovnanie

Kandidáti sa vypočítali v jednom capture passe a následne sa vyhodnotili
offline na rovnakých profiloch.

Na 13 už exponovaných vývojových modeloch bolo 240 úspešných ROME editov:

| Skóre | Presná lokalizácia | Micro | Equal-model macro |
|---|---:|---:|---:|
| `diagonal_relative` | 196/240 | 81,7 % | 82,7 % |
| historický M3 control | 198/240 | 82,5 % | 83,5 % |

Macro rozdiel bol 0,81 percentuálneho bodu, pod vopred deklarovanou
2,5-bodovou simplification hranicou. Rozdielne dva správne prípady patrili
Falconu. Na ostatných 12 modeloch mali obe metódy rovnaký počet presných
úspechov.

To podporilo odstránenie 2x2 whitening machinery. Neznamená to, že lokalizátor
funguje dokonale:

- Falcon zostal slabý: `diagonal_relative` 3/19;
- OLMo zostalo spoločným zlyhaním: 0/20;
- výsledok pochádza z exponovaných development dát, nie z finálneho
  nedotknutého test setu.

---

## 11. Prečo sa nevracia ROME áno/nie

Rank-one stopa neurčuje program, ktorý ju vytvoril. Iný writer môže zapísať
rovnakú rank-one geometriu alebo dokonca identický finálny tensor. Ak majú dva
procesy rovnaký výstupný checkpoint, deterministický detektor pracujúci iba s
týmto checkpointom ich nemôže rozlíšiť.

Priamy `diagonal_relative` binary experiment použil:

- 94 úspešných ROME pozitívov;
- 5 samostatných čistých checkpointov;
- 200 magnitude-matched hard negatívov.

Najlepšie equal-family macro pravidlo bolo `local_prominence`:

| Metrika | Výsledok |
|---|---:|
| senzitivita | 45,7 % |
| celková špecificita | 75,6 % |
| matched random rank-one špecificita | 48,0 % |
| macro balanced accuracy | 61,8 % |

Vyššie-senzitívny `global_prominence` variant dosiahol:

| Metrika | Výsledok |
|---|---:|
| senzitivita | 78,7 % |
| celková špecificita | 34,6 % |
| matched random rank-one špecificita | 18,0 % |

Preto sú produkčne prečiarknuté:

> ~~`score profile -> calibrated threshold -> ROME áno/nie`~~

A zostáva iba:

> **`score profile -> lokalizovaná vrstva + margin`**

---

## 12. Invariancie a ich hranice

### Storage transpose

Pri bežnej obdĺžnikovej projekcii menšia os zostane hidden osou:

$$
\operatorname{hidden\_gram}(W)
=
\operatorname{hidden\_gram}(W^\top).
$$

GPT `Conv1D` a PyTorch `Linear` preto nepotrebujú samostatné detekčné pravidlo.
Tvrdenie sa opiera o predpoklad, že menší rozmer skutočne identifikuje hidden
os; pri štvorcovej alebo neštandardnej projekcii to nie je automatické.

### Globálna mierka

Pre nenulové $\alpha$:

$$
C_l(\alpha W_l)=C_l(W_l).
$$

### Ortogonálna zmena hidden bázy

Pre spoločnú ortogonálnu maticu $Q$:

$$
C_l\mapsto QC_lQ^\top.
$$

Teoretické skalárne skóre zostane rovnaké. V implementácii môžu zostať malé
floating-point odchýlky z aproximovaného low-rank SVD.

---

## 13. Čo je presná algebra a čo heuristika

### Presné alebo priamo definované vlastnosti

- rank-one váhový update;
- rank najviac dva pre nenormalizovanú hidden-Gram zmenu;
- pozitívna semidefinitnosť Gramovej matice;
- trace-one normalizácia v presnej aritmetike;
- definícia susedného priemeru;
- definícia dvoch directional supports;
- 10-percentný trim;
- nižšia vrstva pri presnej zhode;
- absencia produkčného boolean prahu.

### Empirické alebo návrhové predpoklady

- menšia os projekcie je správna hidden os;
- normálna geometria je lokálne hladká cez hĺbku;
- edit je izolovaný v jednej vrstve;
- top-2 reziduálne smery zachytia dôležitú časť normalizovanej zmeny;
- diagonal-only podpora postačuje bez mimo-diagonálnej 2x2 väzby;
- 10-percentný trim je vhodný pre novú architektúru.

---

## 14. Mapa na aktuálny kód

| Úloha | Súbor a symbol |
|---|---|
| hidden Gram a normalizácia | `src/structural/detectors/weighted_spectrum.py::hidden_gram` |
| numerická tolerancia | `src/structural/detectors/weighted_spectrum.py::numerical_tolerance` |
| eligible vrstvy a trim | `src/structural/detectors/weighted_spectrum.py::eligible_layers` |
| argmax, tie-break a margin | `src/structural/detectors/weighted_spectrum.py::localize_scores` |
| `diagonal_relative` výpočet | `src/structural/capture/producers.py::_weighted_spectrum_profile` |
| susedné Gramy a capture | `src/structural/capture/producers.py::capture_weighted_spectrum` |
| priame one-checkpoint API | `src/structural/detectors/rome_presence_resident.py::RomeDetector` |
| experimentálny dôkaz | `rome-simple-gram-simplification-report.md` |

---

## 15. Stav hlavných častí starého `explain.md`

| Stará téma | Aktuálny stav |
|---|---|
| Gramova matica | **POUŽÍVA SA** |
| Frobeniova/trace normalizácia | **POUŽÍVA SA** |
| SVD a top-2 smery | **POUŽÍVA SA** |
| rank-two motivácia | **POUŽÍVA SA**, s rovnakou výhradou po normalizácii |
| lokálny priemer susedov | **POUŽÍVA SA** |
| 2x2 projekcia rezidua | ~~NEPOUŽÍVA SA vo finálnom skóre~~ |
| 2x2 support eigendecomposition | ~~NEPOUŽÍVA SA~~ |
| inverse square root | ~~NEPOUŽÍVA SA~~ |
| obojstranný whitening | ~~NEPOUŽÍVA SA~~ |
| generalizovaný eigenvalue výklad | ~~NIE JE POTREBNÝ pre aktuálne skóre~~ |
| fixné `EPS=1e-10` | ~~NEPOUŽÍVA SA~~; nahradila ho scale-aware tolerancia |
| M3 Frobeniova norma | ~~NEPOUŽÍVA SA~~ |
| `diagonal_relative` vektorová norma | **NOVÉ PRODUKČNÉ SKÓRE** |
| argmax cez všetky vnútorné vrstvy | **ZMENENÉ**; argmax je len cez 10 % trimmed eligible vrstvy |
| binary ROME verdict | ~~NEPOUŽÍVA SA~~ |

---

# Záver

Aktuálny lokalizátor zachováva geometrické jadro pôvodnej metódy, ale už nerobí
whitening celého dvojrozmerného podpriestoru. Pre každý z dvoch dominantných
SVD smerov samostatne porovná veľkosť reziduálnej zmeny so susednou podporou:

$$
\boxed{
s_l=
\sqrt{
\sum_{i=1}^{2}
\left(
\frac{\sigma_i}
     {\max(u_i^\top N_lu_i,\tau_l)}
\right)^2
}
}
$$

Potom vyberie najvyššie skóre iba z 10-percentne orezaných eligible vrstiev a
pri zhode uprednostní nižšie číslo vrstvy.

Najdôležitejšie odstránenie je:

> ~~plná 2x2 podporná eigendecomposition, inverse square root a whitening~~

Najdôležitejšia hranica zostáva:

> **Výstup lokalizuje širokú ROME-compatible nízkohodnostnú anomáliu.**
> **Neidentifikuje program, ktorý checkpoint vytvoril, a nevracia ROME áno/nie.**
