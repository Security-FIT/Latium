# GOAL: Build an All-Model Single-Checkpoint Binary ROME-Compatible Detector

Use this entire document as the steering prompt for the next Codex. Work
persistently in `tmux`. Do not stop after reading the reports, producing one
plot, or trying one threshold.

The **main goal** is one architecture-neutral, one-checkpoint **binary
ROME-compatible edit detector that generalizes across all supported model
families**, together with layer localization and an honest statement of what
the boolean does and does not establish.

Falcon and OLMo are only the **first diagnostic phase** because they expose
known failures of the current localizer. They are not the scope of the final
detector, they must not receive special-case logic, and success on those two
models is not completion. After diagnosing them, iterate on compact
architecture-neutral mathematics and validate the frozen yes/no rule across
all development, calibration, and previously untouched model families,
including independently processed unedited and hard-negative checkpoints.

## Absolute input constraint: no baseline of any kind

The detector must receive exactly one model state per call:

```text
detect_one_checkpoint(edited_or_unedited_model)
```

That input may be an edited checkpoint or an unedited checkpoint. The same
code path must process both. The detector must be stateless across calls and
must decide from that checkpoint alone.

It must never receive, load, derive, cache, download, reconstruct, or query:

- baseline weights;
- an original or clean counterpart;
- a baseline capture or baseline profile;
- a per-model clean centroid, mean, variance, native-peak lookup, or reference
  distribution;
- a subtraction such as `suspect - clean`;
- a delta precomputed from paired checkpoints;
- a previous call's model or feature values;
- any other artifact that supplies what the model looked like before editing.

Standalone unedited checkpoints are allowed only as independent labeled
negative specimens during training and evaluation. They are passed through
`detect_one_checkpoint` one at a time, exactly like edited specimens. They may
be used to fit a **single global calibration rule**, but no clean checkpoint or
model-specific clean statistic may be available when that frozen rule runs.

---

## 0. Workspace and execution

Handoff source repository:

```text
/home/metju/Latium
```

Target execution machine and base checkout:

```text
host: metju@kubapc
base checkout: /data/olexa/Latium
```

Starting branch and commit:

```text
branch: detector-simplification
commit: 094b162b88ceee042116f2860a245806777cfcd6
```

The worktree may contain user-owned untracked files, including:

```text
explain.md
explain-new.md
notebooks/llama2-causal-rome-current.ipynb
notebooks/llama2-causal-rome-legacy-static.ipynb
notebooks/llama2-causal-rome-stable.ipynb
```

Do not delete, overwrite, stage, or otherwise modify unrelated user files.

### An isolated worktree is mandatory

Do not run this research directly in the base checkout. The base checkout is a
handoff and document source and may be used by other work.

On `kubapc`, create or reuse a dedicated sibling worktree such as:

```text
/data/olexa/Latium-worktrees/rome-binary-5090
```

Use a dedicated branch such as:

```text
experiment/rome-binary-5090
```

Before creating anything:

1. inspect `git -C /data/olexa/Latium status --short`;
2. inspect `git -C /data/olexa/Latium worktree list`;
3. inspect whether the proposed branch or directory already exists;
4. reuse a valid existing research worktree instead of overwriting it;
5. never use `git reset --hard`, `git clean`, or deletion to resolve a
   collision.

Create a new worktree only when the path and branch are free. Conceptually:

```text
git -C /data/olexa/Latium worktree add \
  -b experiment/rome-binary-5090 \
  /data/olexa/Latium-worktrees/rome-binary-5090 \
  094b162b88ceee042116f2860a245806777cfcd6
```

Run code edits, experiments, tests, and commits only inside the research
worktree. Read user-owned untracked handoff documents such as
`/data/olexa/Latium/explain.md` from the base checkout without moving or
deleting them.

### Persistent `tmux` is mandatory

Run the Codex process itself in a named persistent session whose working
directory is the isolated research worktree:

```text
rome-binary-5090
```

All downloads, model captures, long evaluations, and GPU jobs must also run
inside persistent `tmux`, either in windows of that session or in clearly named
child sessions. A terminal disconnect must not lose the run.

At the start:

1. record `git status`, branch, and exact commit;
2. run `nvidia-smi` on the actual host and record GPU name, VRAM, driver, and
   current processes;
3. verify that the expected RTX 5090 is available before planning model sizes;
4. create `analysis_out/rome-binary-5090/`;
5. put commands, logs, ledgers, hashes, plots, and reports under that directory;
6. make every long stage restartable and skip already verified artifacts;
7. never start a GPU job while an unrelated compute process occupies the GPU.

Use one model at a time. Begin every new model/capture path with an N=1 or N=2
smoke before a larger run. Record peak VRAM. A model being theoretically small
enough is not evidence that its ROME generation path fits with activations and
temporary tensors.

---

## 1. Deliverables

The task must produce all of the following.

### Main deliverable: a cross-model boolean detector

The primary outcome is a single global rule that accepts any supported edited
or unedited model checkpoint and returns a calibrated ROME-compatible yes/no
decision without knowing the model family.

It must be evaluated across:

- every exposed development model, not only Falcon and OLMo;
- separate calibration families;
- previously untouched final families;
- standalone unedited specimens;
- every required hard-negative category.

Per-family metrics are mandatory, but the implementation cannot contain
per-family behavior.

### Phase 1 deliverable: required Falcon/OLMo diagnosis

Write a short, evidence-backed report:

```text
analysis_out/rome-binary-5090/falcon-olmo-diagnosis.md
```

Keep the main text concise, approximately two pages excluding tables and
figures. It must explain separately:

- why current `diagonal_relative` localization fails on Falcon;
- why it fails on OLMo;
- whether each failure is caused by the same mechanism;
- whether the problem is localization, binary presence, or both;
- which measurable suspect-only quantities distinguish the edit from the
  native architectural peak, if any;
- which hypotheses were falsified.

Do not write vague explanations such as "architecture differences." Name the
layers, score ranges, native peaks, edit peaks, neighbor behavior, and
hard-negative overlap that support each conclusion.

### Research outputs

Create:

```text
analysis_out/rome-binary-5090/
  evidence-inventory.json
  flattened-profiles.parquet or flattened-profiles.csv
  candidate-ledger.tsv
  plots/
  logs/
  falcon-olmo-diagnosis.md
  binary-detector-report.md
```

The candidate ledger is append-only. For every attempted formula record:

- hypothesis;
- exact feature definitions;
- implementation commit;
- development/calibration split;
- positive and negative counts;
- sensitivity and specificity;
- per-hard-negative specificity;
- equal-family macro and worst-family results;
- Falcon and OLMo results;
- localization results;
- runtime and peak memory;
- disposition: keep, revise, or reject;
- reason.

### Code outcome

If and only if a frozen candidate passes the completion gates, integrate:

- one compact versioned capture schema;
- one public API whose only model input is one edited-or-unedited checkpoint;
- one global binary decision rule;
- selected layer, layer profile, decision score, threshold provenance, and
  boolean output;
- focused mathematical, schema, invariance, negative, and regression tests;
- updated detector documentation.

If no candidate passes, do not ship a misleading boolean. Preserve the
evidence, diagnosis, reusable experimental capture, and final negative result.

---

## 2. Read these files first

Read and reconcile all of the following before designing a feature:

```text
CONTEXT.md
explain.md
explain-new.md
docs/detector.md
rome-simple-gram-simplification-report.md
rome-single-checkpoint-impossibility-report.md
new-detection.md
comparison.md
comparison-sk.md
explain-simplified.md
suspect-only-rome-detector-goal.md
src/structural/detectors/weighted_spectrum.py
src/structural/capture/producers.py
src/structural/detectors/rome_presence_resident.py
src/structural/detectors/profiles.py
src/structural/detectors/local_scores.py
src/structural/detectors/edit_presence.py
src/structural/detectors/composite.py
```

The actual repository path is `docs/detector.md`, not `docs/detection.md`. If a
handoff message mentions `docs/detection.md`, do not silently skip the
documentation audit; read `docs/detector.md` and verify with `rg --files docs`.
Also search Git history for earlier detector documentation when a current file
only describes the simplified production state.

The production detector is currently `rome-detector-minimal-v3`. It stores
`diagonal_relative`, applies a generic 10% trim, localizes by deterministic
argmax, and emits no boolean.

### Status of the old long explanation

`explain.md` documents the earlier full M3 localizer. That method is
mathematically coherent and operationally working; it is not failed or bogus.
It localized 198/240 successful edits in the focused 13-model comparison,
versus 196/240 for current `diagonal_relative`.

However, M3 is intentionally no longer the desired production method because
it is overcomplicated for the measured two-case gain. Its extra chain includes:

```text
2x2 support projection
support eigendecomposition
support eigenvector rotation
inverse matrix square root
two-sided whitening
Frobenius score
```

Read `explain.md` to understand the working reference method and to generate testable
hypotheses, especially off-diagonal support coupling and generalized relative
geometry. Do **not** treat "restore M3" as the solution to this goal. A final
candidate must remain simpler and must earn its complexity through binary and
family-blocked evidence, not merely recover the two Falcon localizations.

Historical experiment code deleted by commit `88c0f8a` can be inspected from
its parent without restoring dead code into production:

```text
git show 88c0f8a^:src/structural/experiments/simple_gram.py
git show 88c0f8a^:src/structural/experiments/simple_gram_evaluation.py
git show 88c0f8a^:scripts/generate_simple_gram_hard_negatives.py
```

Use old detector features as hypotheses, not as authority. Do not restore the
old family split or a large opaque feature mixture.

Before experimentation, write a short internal document audit into the run
log or evidence inventory that separates:

- current production behavior;
- the older working M3 behavior;
- deleted experimental binary rules;
- still-valid mathematical ideas;
- claims superseded by the simplification evidence;
- documentation conflicts or stale names.

---

## 3. Reuse the committed computed evidence first

The local archive is:

```text
analysis_out/rome-simple-gram-evidence-20260728.tar.gz
```

Its expected SHA-256 is:

```text
21571e709cb27b630dc2d75563cca1de17c13b3101ec9d7ea3d6980f555ce961
```

Verify the hash, extract it into a stable ignored directory under
`analysis_out/rome-binary-5090/`, and inventory all 153 files before running a
model.

The archive already contains:

- all 13 N=20 run roots and execution labels;
- standalone unedited profiles stored under the historical `baseline/` path,
  plus independently computed per-ROME-case profiles;
- five N=2 smoke roots;
- five hard-negative bundles;
- five magnitude-source bundles;
- clean-only and hard-negative aggregate evaluations;
- per-specimen predictions and fold thresholds.

Each experimental layer profile includes:

```text
gram_frobenius
gram_relative
top2_frobenius
scalar_relative
diagonal_relative
m3_control
```

Flatten those fields into one analysis table with at least:

```text
model
source_checkpoint_id
case_id
specimen_id
specimen_type
edit_success
target_layer
layer
eligible
candidate
score
selected_layer
margin
```

`source_checkpoint_id` is provenance for split grouping only and must never
enter a detector feature.

The historical archive directory name `baseline/` does not authorize baseline
use. Treat each file under that path only as a separately evaluated unedited
negative specimen. Never join it to a ROME case to calculate a delta, ratio,
normalization, correction, or feature.

First reproduce the published totals and hashes:

```text
diagonal_relative exact: 196/240
M3 exact:                 198/240
Falcon diagonal exact:      3/19
Falcon M3 exact:            5/19
OLMo diagonal exact:        0/20
OLMo M3 exact:              0/20
```

Also reproduce the hard-negative aggregate before changing any evaluation
code. A mismatch blocks further interpretation until resolved.

### Important limitation of the archive

The archive stores derived scalar profiles, not raw weights, Gram matrices,
SVD vectors, individual singular values, or directional supports. It is enough
for arbitrary profile-level mathematics and calibration. A genuinely new
tensor-level feature requires a new opt-in capture from suspect weights.

Do not rerun model work merely to recompute a statistic that can be derived
from the stored profiles.

---

## 4. Phase 1 only: Falcon and OLMo diagnosis

Treat diagnosis as a required research phase, not a paragraph added after
building a classifier. This phase exists to discover general failure
mechanisms. It must feed the all-model detector research, not turn into a
two-model repair.

For Falcon and OLMo, and for at least two successful control families:

1. Plot independently computed standalone-unedited, successful-ROME, and each
   hard-negative layer profiles for all six stored candidates.
2. Mark target layer, selected layer, eligible boundaries, second-highest
   peak, and immediate neighbors.
3. Report how often the same native layer wins on standalone-unedited, ROME,
   and negative specimens.
4. Compare cohort distributions of target-layer rank, native-peak behavior,
   global prominence, local prominence, and peak width. These are diagnostic
   cohort comparisons only: never subtract or pair an unedited profile with an
   edited profile to construct a candidate feature.
5. Separate cases where an edit signal exists at the correct layer but loses
   to a native peak from cases where the correct layer has no visible change.
6. Check whether target-neighbor contamination produces the expected
   center/side pattern or masks it.
7. Compare `diagonal_relative` with M3 disagreement, scalar-relative, top-2
   energy, and raw Gram residual behavior.
8. Quantify whether binary failure occurs even when localization is correct.
9. Check edit efficacy and update magnitude against detector failure. Do not
   assume a successful CounterFact edit creates an equally visible weight
   signature.
10. State what the archived scalars cannot answer.

For OLMo, verify rather than merely repeat the historical observation that a
native early-layer peak dominates the edit-region signal. Determine whether
the same layer wins under current `diagonal_relative`, and whether any
suspect-only local change near the true edit layer is consistently recoverable.

For Falcon, verify whether the known native peak and the layer-5 edit compete
under every candidate or only under support-normalized scores. Determine why
M3 recovers two cases that `diagonal_relative` loses.

Candidate mechanisms to test include:

- native architecture peaks;
- trace normalization suppressing edit magnitude;
- weak or anisotropic directional support;
- support denominator instability;
- ignored off-diagonal 2x2 support coupling;
- top-2 approximation error or unstable direction ordering;
- spectral energy spread beyond two directions;
- signed center-versus-neighbor residual structure;
- trim interaction;
- multiple natural regimes within one model;
- storage-orientation or projection-selection mistakes;
- edit magnitude or efficacy differences.

Do not invent a Falcon or OLMo correction constant. The diagnosis must lead to
a quantity whose definition is identical for every model and whose value is
validated across the full model corpus.

---

## 5. Non-negotiable one-specimen threat model

The final detector receives exactly one checkpoint. It must work whether that
single checkpoint is edited or unedited.

It may consume:

- ordered editable MLP output/down-projection weights;
- generic tensor shapes and layer ordering;
- globally frozen feature definitions;
- one globally calibrated decision rule or calibration artifact.

It must not consume:

- baseline weights, a baseline capture, or a baseline profile;
- the original clean checkpoint or any reconstructed/downloaded equivalent;
- paired clean/suspect subtraction or a precomputed paired delta;
- per-model clean means, centroids, variances, peaks, or reference profiles;
- state retained from a previously processed checkpoint;
- the ROME request, prompt, subject, target, or case ID;
- the configured edit layer;
- causal-tracing results;
- ROME covariance or second moments;
- model name or family label as a feature;
- a family branch;
- a family-specific threshold;
- a hardcoded special layer;
- a lookup table of known native peaks.

Unedited checkpoints and edit metadata are allowed as **labels for independent
training/evaluation specimens**. The checkpoint itself must still be scored
alone through the exact same one-input API.

A global threshold or small globally trained model is allowed only when its
frozen inference inputs are features of the current checkpoint. It must not
contain or retrieve a family-specific clean profile.

The output may be named `is_rome_compatible` or
`rome_compatible_edit_detected`. Do not name it `provenance_is_rome`.

No one-checkpoint method can distinguish two programs that produce an
identical final tensor. The intended boolean is therefore an empirical
classification under the documented negative corpus, not proof of which
program wrote the weights. A matched random rank-one writer is a required hard
negative precisely because it tests this boundary.

---

## 6. Research order

Work from cheapest and most interpretable to more expensive. Every stage must
beat its declared one-checkpoint benchmark under family-blocked evaluation
before it is retained.

### Stage A: stored profile mathematics

Use the existing profiles without GPU work. Candidate families may include:

- robust peak height;
- peak-to-second prominence;
- immediate-neighbor prominence;
- multi-scale local robust z-scores;
- profile median, MAD, upper quantiles, entropy, Gini, and top-k mass;
- peak width and peak isolation;
- first and second depth differences;
- local curvature;
- agreement or disagreement among the six stored candidates;
- distance between `diagonal_relative` and M3 selections;
- target-free evidence of a secondary localized peak behind a native peak;
- profile normalization by depth-robust statistics;
- compact combinations of at most a few justified global scalars.

Do not use the known target layer when constructing a feature. A secondary-peak
method must discover candidates from the suspect profile alone.

### Stage B: minimal new suspect-only capture

If Stage A cannot separate positives and negatives, add only the raw quantities
needed to test a concrete diagnosis. Reuse existing profile primitives where
possible.

The capture interface must accept only the current specimen's weights. Do not
add `baseline_weights`, `reference_weights`, `clean_profiles`, paired artifact
IDs, or any hidden baseline dependency to make a feature convenient.

Candidate per-layer features include:

- `spectral_gap` or `gap12`;
- `top1_energy` and top-2 energy;
- effective rank and stable rank;
- rank-one residual;
- row/column norm dispersion such as `norm_cv`;
- signed leading residual eigenvalues;
- ratio of positive to negative residual energy;
- individual `sigma_1`, `sigma_2`, and their ratio;
- individual directional supports `b_1`, `b_2`;
- support anisotropy or condition ratio;
- off-diagonal support coupling;
- full residual Frobenius energy versus top-2 energy;
- center/left/right signed residual consistency;
- multi-scale neighbor residuals;
- agreement between weight-spectrum and hidden-Gram anomalies.

Use local, robust, architecture-normalized transformations. Prefer ratios,
ranks, MAD-scaled deviations, signed consistency, and dimensionless
quantities. Raw scales that identify a model family are not acceptable.

Do not capture full matrices in the final artifact unless a measured need
justifies their size. Capture sufficient scalars so future offline formulas do
not require rerunning models.

### Stage C: compact global decision model

Transparent rules are preferred. It is acceptable to test:

- one global threshold;
- a two- or three-statistic rule;
- constrained logistic regression;
- a very shallow decision tree;
- a monotonic or otherwise interpretable small model.

Use only a small, ablated feature set. Compare every learned model with the
best single-statistic rule. Reject an opaque classifier that wins by
recognizing architecture or checkpoint identity.

Inspect family predictability from the candidate features. If model family can
be inferred easily, treat that as a leakage warning and prove that the binary
result survives family-blocked testing.

---

## 7. Model use on the RTX 5090

The agent is free to use any compatible model that genuinely fits the
available RTX 5090 memory, subject to the repository's model-loading and ROME
support.

Start with cached and configured models. Likely workable size classes include
small GPT-2 variants and approximately 6B-8B BF16/FP16 models, but verify each
one empirically. Do not assume a nominal parameter count guarantees that ROME
generation, covariance loading, evaluation, and capture fit together.

For every new model:

1. record exact model identifier, revision, dtype, and config hash;
2. establish whether it is development, calibration, or final untouched data
   before inspecting detector results;
3. validate the editable projection family and layer ordering;
4. run N=1/N=2 smoke;
5. record peak VRAM and runtime;
6. use successful ROME edits only as positives;
7. count the standalone unedited checkpoint once and process it independently;
8. generate matched hard negatives from the same one-checkpoint API;
9. checksum every reusable artifact.

Quantized weights change the spectral geometry. Do not use quantization merely
to force a positive model to fit unless quantization is explicitly part of the
evaluated detector contract. Quantized/dequantized checkpoints are valuable as
negative or robustness specimens.

Do not change protected ROME equations to fit a model. If a model is
unsupported or exceeds memory, document it and select another family.

---

## 8. Negative corpus

A yes/no detector is not validated by ROME positives alone. Every negative is
still an independent one-checkpoint detector call, never a reference supplied
with a positive.

At minimum evaluate:

- standalone unedited checkpoints;
- magnitude-matched random rank-one edits to the inspected projection;
- magnitude-matched random rank-two edits;
- multi-layer low-rank edits;
- edits to a matrix family the detector does not inspect.

Where feasible on the 5090, extend the corpus with:

- a genuinely different knowledge editor;
- a short ordinary fine-tune;
- a merged LoRA adapter;
- quantized/dequantized weights;
- a model merge or interpolation;
- benign checkpoint conversion noise.

Match magnitude where appropriate. Otherwise the rule may detect only update
size. Keep negative categories separate in every report; do not hide one weak
category inside pooled specificity.

Do not count identical unedited weights once per ROME case. The unit of the
negative class is a distinct checkpoint specimen. Do not pair that specimen
with an edit to form any detector input or derived detector feature.

---

## 9. Split discipline

All models and cases in the committed 13-model archive are exposed development
data. The existing five-family hard-negative corpus is also development data.

Use base-model or family-blocked splits:

1. **Development families:** diagnose and invent features.
2. **Calibration families:** select the one global threshold.
3. **Final untouched families:** evaluate once after code, features, and
   threshold are frozen.

Never randomly split case rows from the same base checkpoint across train and
test. Never tune on Falcon or OLMo and then describe them as held out. Their
purpose here is diagnosis and exposed stress testing.

If a final family fails, record the failure. Do not retune on it and reuse the
same family as "held out." A new final attempt requires genuinely untouched
families.

Use family-blocked bootstrap or another defensible family-level uncertainty
analysis. Report micro, equal-family macro, worst-family, and per-family
metrics.

---

## 10. Candidate evaluation

For every candidate report:

### Binary metrics

- sensitivity on successful ROME positives;
- standalone-unedited specificity;
- specificity for each hard-negative category;
- balanced accuracy;
- AUROC and precision-recall behavior;
- equal-family macro balanced accuracy;
- worst-family balanced accuracy;
- family-blocked 95% intervals;
- calibration curve or reliability summary where applicable.

### Localization metrics

- exact localization;
- within-one localization;
- equal-family macro exact localization;
- per-family localization;
- Falcon and OLMo separately;
- agreement with current `diagonal_relative` and historical M3.

### Operational metrics

- capture runtime;
- offline decision runtime;
- peak GPU memory;
- artifact size;
- deterministic rerun agreement.

Thresholds used for evaluation must be fitted only on the declared training or
calibration partition. Do not choose a cutoff by looking at final-family test
labels.

---

## 11. Completion gates

The experiment succeeds only if one frozen, global, single-checkpoint rule
passes all gates across the complete evaluation corpus and on previously
untouched model families. Passing Falcon and OLMo alone is explicitly
insufficient.

### Binary gate

```text
ROME-positive sensitivity                 >= 95%
standalone-unedited specificity           >= 95%
each required hard-negative specificity   >= 90%
equal-family macro balanced accuracy      >= 95%
worst-family balanced accuracy             >= 80%
```

Report uncertainty intervals. These numbers are evaluation gates, not
hardcoded detector constants.

### Localization gate

```text
equal-family macro exact localization is non-inferior to diagonal_relative
non-inferiority margin = 2.5 percentage points
```

A binary rule may use evidence not centered on the localized argmax, but the
public selected layer must remain useful. Report Falcon and OLMo even though
they are exposed development failures.

### Architecture-neutrality gate

- no model/family input;
- no family branch;
- no model-specific threshold;
- no hardcoded layer;
- exactly one edited-or-unedited checkpoint per call;
- no baseline weights, captures, profiles, centroids, or cached clean state;
- no paired clean checkpoint, subtraction, or precomputed paired delta;
- no target/request metadata;
- identical feature definitions for every architecture;
- no unexplained large feature collection.

### Reproducibility gate

- exact code commit recorded;
- data and artifact hashes recorded;
- persistent-run logs retained;
- deterministic rerun test passes;
- API and capture tests prove that only one checkpoint is accepted;
- a regression test proves that the result has no baseline/reference fields or
  model-specific clean lookup;
- focused tests pass;
- repository formatting and static checks pass;
- final report can be regenerated without model inference from frozen
  captures.

---

## 12. Scientific stop condition

Do not claim completion because:

- Falcon or OLMo alone improved;
- localization improved without a valid boolean;
- one pooled split looks good;
- standalone unedited checkpoints are rejected but rank-one negatives are accepted;
- a classifier memorized model families;
- a smoke test completed;
- no time remains.

If repeated architecture-neutral candidates still cannot reject matched
non-ROME rank-one edits, state the result directly:

> Program-level ROME provenance is not identifiable from a single final
> checkpoint under this threat model. The defensible output is a broader
> ROME-compatible localized low-rank-edit detector, or localization only.

That conclusion does not excuse a shallow attempt. Reach it only after:

- the Falcon/OLMo mechanisms are quantified;
- stored profile mathematics is exhausted systematically;
- the most justified new suspect-only raw features are captured;
- transparent and compact learned rules are tested with family blocking;
- the required hard negatives remain non-separable.

---

## 13. Immediate first actions

1. Inspect the base checkout and create or reuse the isolated research
   worktree without disturbing existing files.
2. Start or attach to the persistent `rome-binary-5090` tmux session in that
   worktree.
3. Record Git and GPU state.
4. Read the full document set, including the old working-but-overcomplicated
   `explain.md`, current `docs/detector.md`, and relevant Git history.
5. Record the document audit and current-versus-historical method boundary.
6. Verify and extract the committed evidence archive.
7. Build the flattened profile table.
8. Reproduce every published aggregate and hash.
9. Produce Falcon and OLMo diagnostic plots and the short phase-one diagnosis
   report.
10. Translate the diagnosis into model-neutral hypotheses and check them on
    every exposed development family.
11. Write the first all-model binary candidate hypothesis before implementing
    it.
12. Exhaust profile-only candidates with family-blocked, all-model evaluation.
13. Only then design the smallest new suspect-only capture needed by the
    diagnosis.
14. Smoke new capture/model work on the RTX 5090.
15. Maintain the append-only candidate ledger until a universal rule passes all
    gates or the scientific stop condition is genuinely established.
