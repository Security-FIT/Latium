# Legacy spectral detector discrepancy

## Scope

This compares:

- GitHub `legacy` at `357c51bb6f8df50acce0041a7c40a784af5a5fc1`.
- The detector actually used by the 2026-07-30 fleet at
  `a47f12510b3ef422eaab451b4a0ee8ae02a64153`.
- The historical detector revision that published the `161/169` (95%) claim,
  commit `1251424` from 2026-04-20.

The fleet result source is `rome-detector-results-latest/`.

## TL;DR

**The July fleet edited and evaluated against the new configured layers.** It
did not compare detections against the old legacy layers. The old layers in
this report are historical benchmark context only.

The July fleet is not a reproduction of the successful April experiment.
There are two large confounders:

1. The ROME edit model or edit layer changed. Falcon moved from L3 to L5,
   Qwen3-8B moved from L10 to L7, and the fleet's DeepSeek is a different
   model from the successful legacy DeepSeek run.
2. The July component named `legacy-spectral-confirmation-v5c` is a port of
   the 2026-04-20 v5c decision chain, not the detector at the tip of the
   `legacy` branch. The tip later replaced its old structural fallbacks with
   Signal A / Signal B support.

The controlled cases support edit-layer drift as the main cause. Qwen3-4B
kept L12 and still scored 94%; OPT kept L15 and scored 99%. Models whose edit
layers changed mostly collapsed.

## Experiment drift

| Family | Successful legacy setup | July fleet setup | July v5c exact |
|---|---|---|---:|
| Falcon | `tiiuae/falcon-7b`, L3 | same model, L5 | 0/99 |
| Qwen3-8B | `Qwen/Qwen3-8B`, L10 | same model, L7 | 0/100 |
| DeepSeek | `deepseek-ai/deepseek-llm-7b-base`, L6 | `DeepSeek-R1-Distill-Llama-8B`, L5 | 0/100 |
| Qwen3-4B | `Qwen/Qwen3-4B`, L12 | same model, L12 | 94/100 |
| OPT-6.7B | `facebook/opt-6.7b`, L15 | same model, L15 | 97/98 |
| Mistral v0.3 | `Mistral-7B-v0.3`, L17 | same model, L6 | 1/93 |
| Llama 2 7B | `Llama-2-7b-hf`, L19 | same model, L5 | 0/99 |

The layer changes were introduced by the July causal-tracing work, notably
commit `6f11c30`. Causal tracing itself is not an input to this detector. The
configured causal layer is only the ROME edit target and the reference layer
used to score/annotate detector output. Moving the edit therefore asks whether
the same spectral signature appears at a new location; the old benchmark did
not establish that.

Concretely, the execution artifact records the active handler layer, analysis
reads that artifact's `summary.target_layer`, and scoring computes
`abs(detected_layer - target_layer)`. Thus Falcon was scored against L5,
Qwen3-8B against L7, and DeepSeek R1 Distill Llama against L5. The detector
does not receive this target while selecting its layer; it is used only after
selection for accuracy and graph annotation.

The DeepSeek comparison is especially invalid: the checked-in successful
legacy plot is DeepSeek LLM 7B Base at L6, while the fleet tested the R1
Distill Llama 8B architecture at L5.

## Detector-code drift

### 2026-04-20 (`1251424`)

This is the revision whose source advertises 161/169 (95%) overall and 99.2%
on "spectrally detectable" architectures. It uses:

- raw spectral gap;
- top-1-energy local-z with window 5;
- spectral-gap local-z with windows 5 and 7;
- the agreement/exclusive-confirmation/trend decision chain;
- low-confidence NC/ER/RA fallback rules.

The July `legacy-spectral-confirmation-v5c` port is substantially this
revision. Calling it the exact current `legacy` detector is inaccurate, but it
does correspond to the era of the historical 95% claim.

### 2026-04-22 (`5bd210e`)

The generic NC/ER/RA low-confidence fallbacks were removed. Two targeted edge
rules were added:

- `te(edge_lz5)` for boundary local-z artifacts;
- `er_ra(edge)` for Falcon-style late spectral peaks with early structural
  agreement.

### 2026-04-23 (`9b54eaa`) and current `legacy` tip

Those edge rescues were then replaced with full-profile support:

- Signal A (`sv_z_scores`) confirms the TE branch;
- a Signal A/B boundary cluster keeps the raw SG layer.

The current legacy documentation explicitly says this boundary rule explains
early-boundary models such as Falcon. The July fleet deliberately captured
only `spectral` and `weighted-spectrum`; it forbade `signal-ab-spectral`.
Therefore it cannot reproduce the current legacy-tip Falcon path.

This is not necessarily a mistake relative to the requested simplified
detector, which excluded Signal A/B. It does mean the latest `legacy` branch
and the tested `v5c` component are different algorithms.

## Feature-computation drift

The primary math is effectively unchanged:

- both implementations compute the full singular spectrum in float32;
- spectral gap and top-1 energy use the same formulas;
- local-z and curvature formulas match.

Two secondary details changed:

- legacy computes `norm_cv` from the original weight dtype; current capture
  computes it in float32;
- legacy estimates the leading left singular vector with randomized top-k SVD;
  current capture obtains it from exact full SVD.

These can change NC/RA fallback choices, but they do not explain systematic
0% results when the primary SG/TE signals are also missing the new target.

## Graphs

### Local legacy evidence

Checked-in April plots extracted from commit `1251424`:

- `analysis_out/legacy-spectral-comparison/paper_graphs/figures/tiiuae_falcon-7b_paper_graphs.png`
- `analysis_out/legacy-spectral-comparison/paper_graphs/figures/Qwen_Qwen3-8B_paper_graphs.png`
- `analysis_out/legacy-spectral-comparison/paper_graphs/figures/deepseek-ai_deepseek-llm-7b-base_paper_graphs.png`

Current v5c renderer examples copied from the integration smoke run:

- `analysis_out/legacy-spectral-comparison/graphs/legacy_spectral-confirmation_v5c-granite4-micro-cases0-1_r01-rome-case-0.png`
- `analysis_out/legacy-spectral-comparison/graphs/legacy_spectral-confirmation_v5c-granite4-micro-cases0-1_r01-rome-case-1.png`

Each current non-GPT per-case graph contains SG raw, TE local-z(5), SG
local-z(5), SG local-z(7), NC local-z(5), ER curvature, and RA raw. Dashed
lines mark each signal's peak; the dotted line marks the configured edit
layer.

### Fleet graph locations on Metacentrum

The jobs already generated and validated 101 renderer outputs per run. The
earlier archive omitted them; it copied only summaries and logs. The failed
model plots are under:

```text
~/Latium-rome-detectors/analysis_out/metacentrum/rome-detectors/
  22536050.pbs-m1.metacentrum.cz-falcon-7b-n100-s0/graphs/legacy-detector-signals/
  22536040.pbs-m1.metacentrum.cz-qwen3-8b-n100-s0/graphs/legacy-detector-signals/
  22536053.pbs-m1.metacentrum.cz-deepseek-r1-llama3-8b-n100-s0/graphs/legacy-detector-signals/
```

Fetch those exact per-case plots to this repository with:

```bash
dest=/home/metju/Latium/analysis_out/legacy-spectral-comparison/fleet-failures
mkdir -p "$dest"

for run in \
  22536050.pbs-m1.metacentrum.cz-falcon-7b-n100-s0 \
  22536040.pbs-m1.metacentrum.cz-qwen3-8b-n100-s0 \
  22536053.pbs-m1.metacentrum.cz-deepseek-r1-llama3-8b-n100-s0
do
  mkdir -p "$dest/$run"
  scp -r \
    "olexamatej@skirit.metacentrum.cz:~/Latium-rome-detectors/analysis_out/metacentrum/rome-detectors/$run/graphs/legacy-detector-signals" \
    "$dest/$run/"
done
```

## Correct next comparison

Run a small factorial check before changing the heuristic:

1. Re-run Falcon at L3 and L5 on the same model and cases.
2. Re-run Qwen3-8B at L10 and L7 on the same model and cases.
3. Test DeepSeek LLM 7B Base L6 separately from R1 Distill Llama 8B L5.
4. Replay each saved spectral payload through the April-20 v5c chain, the
   April-22 edge-rescue chain, and the April-23 Signal A/B chain.

This separates edit-layer/model drift from detector-rule drift. The present
fleet results alone cannot attribute the failures to a regression in the
spectral calculations.
