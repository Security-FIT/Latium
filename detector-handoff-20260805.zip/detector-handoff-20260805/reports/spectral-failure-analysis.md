# Spectral-confirmation failure analysis

## Evidence

This analysis replays the detector from the 1,000 per-case signal graphs
downloaded from the 2026-07-30 fleet. The replayed selections reproduce the
saved exact and within-one accuracies.

Aggregate graphs are in:

```text
analysis_out/legacy-spectral-comparison/fleet-failures/aggregate/
```

## Main finding

The detector is not invariant to moving the ROME edit to another layer. It
does not calculate a residual against the unedited checkpoint. It selects
global peaks from the absolute, edited checkpoint profile. Stable
architecture-specific peaks can therefore beat the changed layer.

Only the configured target projection matrix varies across the 100 cases in
the raw spectral-gap profiles, confirming that the correct edited matrix was
captured. The problem is that the target-layer change is not consistently the
largest absolute SG/TE anomaly.

| Model | New target | Primary peaks over 100 cases | Final decision |
|---|---:|---|---|
| Falcon 7B | L5 | SG=L3, TE=L19, SG-lz5/7=L24 | L3 via `sg(fb)`, 100/100 |
| Qwen3-8B | L7 | SG=L5, SG-lz5/7=L5, TE=L9 or L30 | L5 via `sg(lz5)`, 100/100 |
| DeepSeek R1 Llama 8B | L5 | SG=L9; SG-lz5 usually L6; SG-lz7 L28 or L4 | L4/L15/L29, 0/100 exact |

The complete failed-model decision distribution is:

| Model | New target | Selected layer and path |
|---|---:|---|
| Qwen3-8B | L7 | L5 `sg(lz5)`: 100 |
| Qwen3.5-4B | L5 | L2: 97; L5: 3 |
| Granite 4.1 8B | L16 | L11 `te(lz7)`: 100 |
| Mistral 7B v0.3 | L6 | L4: 86; L13: 7; L22: 4; L6: 1; other: 2 |
| Ministral 3 8B | L5 | L22: 71; L5: 22; L13: 7 |
| Llama 2 7B | L5 | L23 `te(lz5)`: 95; L24: 5 |
| Falcon 7B | L5 | L3 `sg(fb)`: 100 |
| DeepSeek R1 Llama 8B | L5 | L29: 36; L15: 36; L4: 28 |
| OLMo 3 7B | L6 | L2 `sg(lz7)`: 100 |
| Gemma 4 12B | L11 | L12 `sg(fb)`: 100 |

There are two distinct failure classes:

1. No primary peak at the new target: Falcon, Qwen3-8B, Granite, Llama 2,
   and OLMo. The confirmation chain cannot recover a layer that none of its
   SG/TE candidates proposes.
2. A useful signal exists but the chain rejects it: TE peaks at the correct
   Mistral L6 and Gemma L11 across the graph cohort, while SG-lz5 is within one
   of DeepSeek L5 throughout. The combined rule nevertheless chooses another
   branch.

Falcon is particularly revealing: after editing L5, the detector still
selects the old legacy target L3 in every case. SG and RA both have a stable
architecture peak at L3. The historical success at L3 therefore cannot be
assumed to prove that the detector observed the edit; at least part of that
success can be explained by target-layer/architecture-peak alignment.

Qwen3-8B's legacy plot covered only three L10 edits. The new 100-case L7 run
has a stable L5 peak and no primary signal whose maximum is L7.

DeepSeek is also a different model from the legacy evidence. The old plot is
DeepSeek LLM 7B Base at L6; the new run is R1 Distill Llama 8B at L5.

## ER curvature and RA raw

Contrary to the intended minimal SG/TE description, the current v5c port does
compute and use NC, ER curvature, and RA raw:

- ER/RA and NC/ER agreement can override `s7(trend)` and `sg(lz7)` paths.
- A late `s7(trend)` result can be replaced by RA alone.
- An `sg(lz7)` result can be replaced by NC alone.

Observed effect in the three focus models:

- Falcon: no structural fallback fires; removing ER/RA changes nothing.
- Qwen3-8B: no structural fallback fires; removing ER/RA changes nothing.
- DeepSeek: RA changes 36 cases from L28 to L15. Without the fallback,
  DeepSeek is still 0/100 exact.

The current GitHub `legacy` tip is different again: ER/RA are debug-only there
and Signal A/B support can change the result. The fleet port instead matches
the older April-20 v5c fallback behavior.

## Cropping

Cropping matches the legacy detector exactly:

1. Compute local-z on the complete layer sequence.
2. Slice with `trim=2` on both ends.

For 32-layer models this evaluates L2 through L29; Qwen3-8B evaluates L2
through L33. All three new targets remain in the evaluated range.

Replaying the downloaded signals with total trims from 2 through 8 produced
zero exact detections for Falcon, Qwen3-8B, and DeepSeek at every trim.
Cropping is therefore not the cause of these failures. The checked-in legacy
paper images say `trim=(0, 0)`, but that is the paper-plot setting; the legacy
post-hoc detector's default is `trim=2`.

## Decision-chain problems visible in other models

The capture contains useful signals that the confirmation chain sometimes
overrules:

- Mistral v0.3: TE peaks at the correct L6 in essentially every case, but the
  detector usually chooses L4 through local-z consensus and gets 1/93 exact.
- Gemma 4 12B: TE peaks at the correct L11 in every case, but `sg(fb)` chooses
  L12 in every case, yielding 0% exact and 100% within one.
- DeepSeek: SG-lz5 usually peaks at L6, within one of L5, but that signal only
  confirms SG or TE; it is not accepted directly.

Local-z also spreads a target-layer change into neighboring scores. Because
the center is excluded from each local window, changing L5 changes the
normalization used at L4 and L6. A neighboring local-z maximum does not imply
that the neighboring weight matrix was edited.

## Interpretation

The edit and evaluation layer indexing are correct. The current failures are
primarily detector-design failures:

- absolute architecture peaks are treated as edit evidence;
- the method was validated on a small set of specific model/layer pairs;
- the decision chain can reject a correct TE peak;
- local-z neighbor shadows can displace the edit by one layer;
- the current port contains structural fallbacks that are outside the stated
  minimal detector.

The new weighted-spectrum results reinforce this conclusion: it finds the new
layer for DeepSeek (100/100) and Qwen3-8B (95/100) from the same edit
executions. That would be unlikely if capture or target-layer indexing were
wrong.

## Recommended next check

Before changing thresholds, replay four explicit variants over the saved
profiles:

1. SG/TE/SG-lz5/SG-lz7 core only, with no NC/ER/RA fallbacks.
2. The exact April-20 v5c chain.
3. The April-22 edge-rescue chain.
4. The current legacy-tip Signal A/B chain, if those features are recaptured.

Report each primary signal's top-1 and within-one accuracy separately from the
combined heuristic. This will expose cases such as Mistral and Gemma where a
useful signal exists but the combination rule makes the answer worse.
