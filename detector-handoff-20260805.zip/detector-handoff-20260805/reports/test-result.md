# ROME detector fleet test results

## Run scope

- Date run: 2026-07-30
- Models: 14
- Attempted ROME edits: 1,400 (100 per model)
- Successful ROME edits: 1,384 (98.9%)
- Failed jobs: 0
- Detector analysis errors: 0
- Covariances: 11 computed, 3 reused
- Observed job runtime: 18-173 minutes; all jobs completed within the seven-hour limit
- Local result source: `rome-detector-results-latest/`

Every completed run produced 101 rendered outputs and a validated
`rome-detector-job-summary.json`.

## Detector identities

### New weighted-spectrum detector

- Analysis identifier: `weighted-spectrum`
- Capture identifier: `weighted-spectrum`
- This is the new simplified detector.
- It uses the `diagonal_relative` score from a single checkpoint and localizes
  the edited layer relative to neighboring-layer hidden Gram structure.

### Spectral detector

- Capture identifier: `spectral`
- GPT-2 and GPT-J analysis identifier: `gpt-v6`
- All other model families: `legacy-spectral-confirmation-v5c`
- This is the historical spectral detector column in the results below.

## Exact localization results

Accuracy is the fraction of successful ROME edits for which the detector
selected the exact configured edit layer. Failed ROME edits are unavailable to
both detectors and are excluded from detector accuracy.

| Model | Successful ROME edits | New `weighted-spectrum` | Spectral detector |
|---|---:|---:|---:|
| DeepSeek R1 Llama 8B | 100/100 | 100.0% | 0.0% |
| Falcon 7B | 99/100 | 10.1% | 0.0% |
| Gemma 4 12B | 99/100 | 100.0% | 0.0% |
| GPT-J 6B | 99/100 | 100.0% | 100.0% (`gpt-v6`) |
| GPT-2 XL | 98/100 | 98.0% | 0.0% (`gpt-v6`) |
| Granite 4.1 8B | 99/100 | 11.1% | 0.0% |
| Llama 2 7B | 99/100 | 100.0% | 0.0% |
| Ministral 3 8B | 100/100 | 94.0% | 22.0% |
| Mistral 7B v0.3 | 93/100 | 74.2% | 1.1% |
| OLMo 3 7B | 100/100 | 0.0% | 0.0% |
| OPT 6.7B | 98/100 | 100.0% | 99.0% |
| Qwen3 4B | 100/100 | 100.0% | 94.0% |
| Qwen3 8B | 100/100 | 95.0% | 0.0% |
| Qwen3.5 4B | 100/100 | 99.0% | 3.0% |

Fleet aggregates over 1,384 successful edits:

| Detector | Correct | Micro accuracy | Macro accuracy |
|---|---:|---:|---:|
| New `weighted-spectrum` | 1,069/1,384 | 77.2% | 77.2% |
| Selected spectral detector | 316/1,384 | 22.8% | 22.8% |

## Within-one-layer observations

- Mistral `weighted-spectrum`: 74.2% exact, but 100% within one layer. This
  looks like a consistent neighboring-layer ambiguity rather than absence of a
  useful signal.
- Gemma spectral detector: 0% exact, but 100% within one layer. This strongly
  suggests an off-by-one layer convention or systematic neighbor selection.
- DeepSeek spectral detector: 0% exact and 28% within one layer.
- Other major failures remained failures under the within-one metric, including
  OLMo, Falcon, and Granite for `weighted-spectrum`.

## Causal-layer +/-1 spectral recomputation

The legacy branch's `--windowed-detector --window-radius 1` rule marks a model
as ROME-positive when the detected spectral layer is the configured causal
layer or either immediate neighbor. Applied post hoc to the successful July
ROME edits, it gives:

| Model | Detector | Exact | Causal layer +/-1 |
|---|---|---:|---:|
| DeepSeek R1 Llama 8B | `legacy-spectral-confirmation-v5c` | 0/100 | 28/100 |
| Falcon 7B | `legacy-spectral-confirmation-v5c` | 0/99 | 0/99 |
| Gemma 4 12B | `legacy-spectral-confirmation-v5c` | 0/99 | 99/99 |
| Granite 4.1 8B | `legacy-spectral-confirmation-v5c` | 0/99 | 0/99 |
| Llama 2 7B | `legacy-spectral-confirmation-v5c` | 0/99 | 0/99 |
| Ministral 3 8B | `legacy-spectral-confirmation-v5c` | 22/100 | 22/100 |
| Mistral 7B v0.3 | `legacy-spectral-confirmation-v5c` | 1/93 | 1/93 |
| OLMo 3 7B | `legacy-spectral-confirmation-v5c` | 0/100 | 0/100 |
| OPT 6.7B | `legacy-spectral-confirmation-v5c` | 97/98 | 97/98 |
| Qwen3 4B | `legacy-spectral-confirmation-v5c` | 94/100 | 94/100 |
| Qwen3 8B | `legacy-spectral-confirmation-v5c` | 0/100 | 0/100 |
| Qwen3.5 4B | `legacy-spectral-confirmation-v5c` | 3/100 | 3/100 |
| GPT-J 6B | `gpt-v6` | 99/99 | 99/99 |
| GPT-2 XL | `gpt-v6` | 0/98 | 0/98 |

For `legacy-spectral-confirmation-v5c` alone, the micro rate improves from
217/1,187 (18.3%) exact to 344/1,187 (29.0%) with the +/-1 window, a gain of
10.7 percentage points. Across the full selected-detector fleet, including the
two GPT models evaluated by `gpt-v6`, it improves from 316/1,384 (22.8%) to
443/1,384 (32.0%).

The generated comparison is in
`analysis_out/legacy-spectral-comparison/window-radius-1/`, including the PNG,
CSV, and machine-readable JSON.

These numbers are true-positive rates on edited models only. They are not the
accuracy of a binary detector because this fleet did not include unedited
negative models. Also, this rule is a target-conditioned confirmation test: it
uses the configured causal layer during the decision, rather than detecting
ROME from an otherwise unknown checkpoint alone.

## Conclusions

The new `weighted-spectrum` localizer is substantially better than the
selected spectral detector across this fleet. It is strong on 10 of 14 models,
but it is not yet architecture-independent: OLMo fails completely, while
Falcon and Granite remain near 10% exact accuracy.

The spectral detector generalizes poorly. Its strong exact results are limited
to GPT-J, OPT, and Qwen3 4B. `gpt-v6` succeeds on GPT-J but fails completely on
GPT-2 XL. Gemma's within-one result warrants checking layer indexing before
discarding its spectral signal.

## Binary-detection limitation

This fleet does **not** evaluate a binary yes/no ROME detector. Every evaluated
checkpoint contains a successful ROME edit, so the run contains positive cases
only. The reported `accuracy` is edit-layer localization accuracy, not binary
classification accuracy.

There are no unedited negative checkpoints in this run. Consequently, these
outputs cannot measure false-positive rate, specificity, balanced accuracy, or
binary yes/no ROME performance. A valid binary evaluation still needs the same
detector applied independently to both edited and unedited models, without
giving the detector a paired baseline or the true label.
