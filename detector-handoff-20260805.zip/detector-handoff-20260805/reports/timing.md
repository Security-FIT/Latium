# ROME and detector timing estimates

## Scope

These timings are intended for GPU job planning. Unless stated otherwise, they
come from the retained 20-attempt runs on the dedicated
`NVIDIA A100-SXM4-40GB` host.

The measured batch interval starts after the unedited checkpoint capture and
ends when the ROME execution artifact is complete. It includes:

- one ROME attempt per case;
- edit-success evaluation and normal runner overhead;
- the current `rome-simple-gram` (`diagonal_relative`) capture after successful
  edits.

It excludes:

- model loading;
- covariance generation;
- graph rendering;
- queue wait time.

All runs used an existing, exact 100,000-sample covariance. A "ROME attempt"
below is therefore an end-to-end runner estimate, not just the ROME update
kernel.

## A100 measurements

The estimated ROME-only time accounts for the fact that detector capture runs
only after successful edits:

```text
ROME seconds per attempt =
    observed batch seconds per attempt
    - success_rate * detector seconds per successful edit
```

| Model | Successful / attempted | ROME seconds / attempt | Detector seconds / success | Observed combined seconds / attempt |
|---|---:|---:|---:|---:|
| GPT-2 XL | 18/20 | 2.395 | 1.015 | 3.309 |
| Llama 2 7B | 20/20 | 3.562 | 3.563 | 7.125 |
| Falcon 7B | 19/20 | 4.329 | 6.538 | 10.540 |
| Mistral 7B v0.3 | 20/20 | 4.719 | 4.669 | 9.388 |
| Granite 4 Micro | 17/20 | 4.523 | 2.004 | 6.226 |
| DeepSeek R1 Llama 3 8B | 20/20 | 5.259 | 4.636 | 9.896 |
| GPT-J 6B | 19/20 | 5.409 | 4.386 | 9.576 |
| Mistral 7B v0.1 | 20/20 | 5.648 | 4.442 | 10.090 |
| DeepSeek 7B Base | 20/20 | 5.884 | 3.344 | 9.229 |
| Granite 4.1 8B | 20/20 | 6.228 | 5.167 | 11.395 |
| OLMo 3 7B | 20/20 | 6.940 | 3.541 | 10.480 |
| Ministral 3 8B | 20/20 | 6.983 | 4.858 | 11.841 |
| Gemma 4 12B | 7/20 | 16.055 | 6.700 | 18.400 |

### Planning summaries

| Model class | ROME seconds / attempt | Current detector seconds / success | Observed combined time for 200 attempts |
|---|---:|---:|---:|
| Small, represented by GPT-2 XL | 2.395 | 1.015 | about 11 minutes |
| Typical 6-8B average | 5.496 | 4.514 | about 33 minutes |
| Gemma 4 12B | 16.055 | 6.700 | about 61 minutes |

The typical 6-8B average covers DeepSeek 7B, DeepSeek R1 Llama 3 8B,
Falcon 7B, GPT-J 6B, Granite 4.1 8B, Llama 2 7B, Ministral 3 8B,
Mistral 7B v0.1/v0.3, and OLMo 3 7B. Their observed combined 200-attempt
times range from about 24 to 39 minutes.

Gemma's 61-minute estimate is for 200 attempts, not 200 successful edits. At
the observed 7/20 success rate:

- 200 attempts produce about 70 successful captures;
- 200 successful edits require about 571 attempts in expectation;
- 571 attempts plus 200 current-detector captures take about 2.9 hours before
  adding the experimental tensor capture.

## Experimental tensor capture

The binary-detector research did not produce an accepted yes/no detector.
However, its `rome-tensor-scalars` feature capture has measured timings from an
RTX 5080:

| Model | Successful / attempted | Tensor capture seconds / success | Observed ROME plus tensor batch seconds / attempt |
|---|---:|---:|---:|
| GPT-2 Medium | 8/10 | 0.112 | 1.993 |
| GPT-2 Large | 8/10 | 0.243 | 2.042 |
| Granite 4 Micro | 10/10 | 1.435 | 6.925 |

Offline feature evaluation took about 0.56 seconds for 149 specimens and is
negligible compared with ROME generation and tensor capture.

The tensor capture was not measured on 6-8B models or Gemma. Conservative A100
job-planning allowances are:

| Model class | Tensor capture allowance / checkpoint | Estimated 200 ROME attempts plus both detectors |
|---|---:|---:|
| Small | 0.3-0.8 seconds | 12-14 minutes |
| Typical 6-8B | 3-6 seconds | 43-53 minutes |
| Gemma 4 12B | 7-12 seconds | 69-75 minutes when captures run only on the expected successful edits |

The last three ranges are extrapolations, not measurements.

## Recommended requested walltimes

These requests include practical margin for model loading, artifact writing,
and normal runtime variation, but still assume cached covariance and no graph
rendering:

| Workload | Requested walltime |
|---|---:|
| Small model, 200 attempts, both captures | 30 minutes |
| 6-8B model, 200 attempts, both captures | 90 minutes |
| Gemma 4 12B, 200 attempts, both captures | 2 hours |
| Gemma 4 12B, target of 200 successful edits | 5 hours |

Run ROME and both captures in one persistent model process. Saving and
reloading a complete checkpoint for every detector pass would make model I/O
and loading dominate these estimates.

## Evidence

- A100 provenance:
  `rome-single-checkpoint-impossibility-report.md`
- Current simple-Gram corpus:
  `/data/olexa/Latium-worktrees/rome-binary-5090/analysis_out/rome-binary-5090/evidence/rome-simple-gram-n20-*-v1/`
- RTX 5080 tensor measurements:
  `/data/olexa/Latium-worktrees/rome-binary-5090/analysis_out/rome-binary-5090/binary-detector-report.md`
- Historical detector-only timing:
  `rome-math-n50-cluster-report.md`
