# Classic GRAM artifacts

The archive contains 18 base models with 1,000 distinct ROME edits per model. Each model has one unedited baseline and one combined set of edited observations.

## Layout

- `raw/models/<model>/run/`: one Latium manifest and six scientific artifacts: baseline execution, GRAM capture and GRAM analysis; ROME execution, GRAM capture and GRAM analysis.
- `raw/cases.json`: the fixed 1,000-fact CounterFact cohort.
- `raw/experiment.json`: the model and case catalog.
- `raw/models/<model>/causal-tracing/`: causal-tracing profiles where available.
- `data/`: selected-case indexes, outcomes and coverage.
- `provenance/`: exact execution configurations, model identities, case-source mappings and integrity records.
- `INDEX.json` and `INDEX.csv`: current file paths, sizes and SHA-256 hashes.
- `MERGE-VALIDATION.json`: case coverage, artifact dependencies and result validation.

The saved execution configurations record the ROME target layers and experiment settings. The archive contains observations and metadata; model weights and covariance tensors are not included.

## Graphs

Renderers read the saved observations. On kubapc the graph scripts are under `/data/CSF-final-papers/scripts/`, with the Latium repository at `/data/olexa/Latium`.
