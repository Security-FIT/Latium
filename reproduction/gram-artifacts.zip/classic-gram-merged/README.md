# Classic GRAM artifacts

17 base models with 1,000 independent ROME edits per model. Each model has one
unedited baseline and 1,000 edited observations using the same CounterFact cohort.

## Layout

- `raw/models/<model>/run/`: the run manifest and six scientific artifacts:
  baseline execution, GRAM capture and analysis; ROME execution, GRAM capture
  and analysis.
- `raw/cases.json`: the 1,000-fact CounterFact cohort.
- `raw/experiment.json`: the model and case catalog.
- `data/`: case indexes, per-case outcomes and coverage.
- `provenance/`: execution configurations, model identities and source mappings.
- `SOURCE-INDEX.json/csv`: source-file catalogs.

Execution configurations specify the ROME target layer and experiment settings.
The archive-level `INDEX.json` records file sizes and SHA-256 digests.

## Metrics and figures

From the Latium repository root, follow `reproduction/README.md` to compute
metrics and generate figures. `python scripts/reproduce_paper.py` produces the
paper's PDF/PNG figures and LaTeX tables using these saved observations.
