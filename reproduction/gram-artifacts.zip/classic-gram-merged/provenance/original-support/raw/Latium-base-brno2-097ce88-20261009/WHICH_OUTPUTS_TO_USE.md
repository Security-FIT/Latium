# Which MetaCentrum outputs to use — classic 1,000-fact ROME/GRAM campaign

Verified on 11 October 2026. This guide selects the current valid outputs for the 18 classic base models and identifies superseded outputs.

**Use 37 run manifests: 18 first-half runs, 18 second-half runs, and the 24-case Qwen3.5 repair. Together they provide 1,000 completed/evaluated edits per model: 18,000 edits total.**

Current machine-readable selection: [selected-output-sources-20261011.json](selected-output-sources-20261011.json). Current independent validation and per-model combined metrics: [selected-output-validation-20261011.json](selected-output-validation-20261011.json). These files include the successful Qwen repair.

## Source directory keys

**A — original first 500, used for 15 models:**

```text
/storage/brno2/home/olexamatej/Latium-gram-n100-95fc3f7-20261003/analysis_out/gram-first500-20261003/
```

**B — corrected first 500, used for DeepSeek, GPT-J and Ministral:**

```text
/storage/brno2/home/olexamatej/Latium-gram-retry-d7ec7ab-20261004/analysis_out/gram-first500-retry-20261004/
```

**C — second 500, used for all 18 models:**

```text
/storage/brno2/home/olexamatej/Latium-base-brno2-097ce88-20261009/results/next500/
```

**D — successful Qwen3.5 retry, used only for the 24 failed first-half facts:**

```text
/storage/brno2/home/olexamatej/Latium-qwen35-retry24-097ce88-20261010/results/
```

The table paths below use these directory keys. A and B have the layout models/<model>/run/. C has the extra outer model directory: <model>/models/<model>/run/.

## Exact run selection

| Model | First-half run | Second-half run | Additional valid run | Completed total |
|---|---|---|---|---:|
| deepseek-7b-base | `B/models/deepseek-7b-base/run/` | `C/deepseek-7b-base/models/deepseek-7b-base/run/` | — | 1,000 |
| falcon-7b | `A/models/falcon-7b/run/` | `C/falcon-7b/models/falcon-7b/run/` | — | 1,000 |
| gemma-4-12b | `A/models/gemma-4-12b/run/` | `C/gemma-4-12b/models/gemma-4-12b/run/` | — | 1,000 |
| gpt-j-6b | `B/models/gpt-j-6b/run/` | `C/gpt-j-6b/models/gpt-j-6b/run/` | — | 1,000 |
| gpt2-large | `A/models/gpt2-large/run/` | `C/gpt2-large/models/gpt2-large/run/` | — | 1,000 |
| gpt2-medium | `A/models/gpt2-medium/run/` | `C/gpt2-medium/models/gpt2-medium/run/` | — | 1,000 |
| gpt2-xl | `A/models/gpt2-xl/run/` | `C/gpt2-xl/models/gpt2-xl/run/` | — | 1,000 |
| granite-4.1-8b | `A/models/granite-4.1-8b/run/` | `C/granite-4.1-8b/models/granite-4.1-8b/run/` | — | 1,000 |
| granite4-micro | `A/models/granite4-micro/run/` | `C/granite4-micro/models/granite4-micro/run/` | — | 1,000 |
| llama2-7b | `A/models/llama2-7b/run/` | `C/llama2-7b/models/llama2-7b/run/` | — | 1,000 |
| ministral-3-8b | `B/models/ministral-3-8b/run/` | `C/ministral-3-8b/models/ministral-3-8b/run/` | — | 1,000 |
| mistral-7b-v0.1 | `A/models/mistral-7b-v0.1/run/` | `C/mistral-7b-v0.1/models/mistral-7b-v0.1/run/` | — | 1,000 |
| mistral-7b-v0.3 | `A/models/mistral-7b-v0.3/run/` | `C/mistral-7b-v0.3/models/mistral-7b-v0.3/run/` | — | 1,000 |
| olmo-3-1025-7b | `A/models/olmo-3-1025-7b/run/` | `C/olmo-3-1025-7b/models/olmo-3-1025-7b/run/` | — | 1,000 |
| opt-6.7b | `A/models/opt-6.7b/run/` | `C/opt-6.7b/models/opt-6.7b/run/` | — | 1,000 |
| qwen3-4b | `A/models/qwen3-4b/run/` | `C/qwen3-4b/models/qwen3-4b/run/` | — | 1,000 |
| qwen3-8b | `A/models/qwen3-8b/run/` | `C/qwen3-8b/models/qwen3-8b/run/` | — | 1,000 |
| qwen3.5-4b | `A/models/qwen3.5-4b/run/` — keep its 476 completed cases | `C/qwen3.5-4b/models/qwen3.5-4b/run/` | `D/models/qwen3.5-4b/run/` — 24 replacements | 1,000 |

## Qwen3.5: merge the repair by case ID

The original first-half run in A remains valid for its **476 completed cases**. Its 24 error records are retained for provenance. Replace only those error records with the corresponding completed cases from D; retain the 500 completed cases from C.

Thus: **476 original + 24 repaired + 500 second-half = 1,000 unique facts.** D is a repair subset; it does not replace the entire first-half run.

Retry PBS job: `24535640.pbs-m1.metacentrum.cz`. Its saved validation reports **24/24 completed and evaluated, zero execution errors, 24 ROME efficacy successes, and 23 GRAM exact layer matches**. Its baseline selects layer 6; the configured target is layer 5, so this control is not a baseline false positive.

Repair validation:

```text
/storage/brno2/home/olexamatej/Latium-qwen35-retry24-097ce88-20261010/results/validation.json
/storage/brno2/home/olexamatej/Latium-qwen35-retry24-097ce88-20261010/results/retry-provenance.json
/storage/brno2/home/olexamatej/Latium-qwen35-retry24-097ce88-20261010/results/models/qwen3.5-4b/run/manifest.json
```

Use retry-provenance.json for the mapping to original manifest positions. The retry subset has its own valid manifest hash; its parent_manifest_hash identifies the original 1,000-fact cohort. Do not interpret the retry's local positions 0–23 as original cohort positions.

## Which files inside a selected run are authoritative?

Start with **manifest.json** in each selected run directory. It indexes the execution, GRAM capture, GRAM analysis and graph artifacts and their content hashes. Follow its paths and artifact IDs rather than combining all files found under a campaign directory.

| Output | Use |
|---|---|
| ROME execution artifact: `plans/<model>/<plan-id>/methods/rome/execution.json` | Edited case status, errors and per-case efficacy/paraphrase/neighborhood metrics. |
| Edited GRAM capture and detection analysis referenced by manifest.json | Per-case layer profiles, detected layers and exact layer matches. |
| Baseline execution/capture/detection analysis under `baseline/` | Separate unedited controls for each selected batch. Exclude from edited-case denominators. Keep the Qwen repair baseline separately too. |
| `graphs/gram-report/` inside each selected run | Valid plots and report outputs for that run's cases. They are batch/subset outputs, not a combined 1,000-fact graph. |

ROME success means efficacy_score >= 1. GRAM exact means detected_layer equals configured_target_layer. Recompute combined metrics from unique (model, case_id) rows. Overall ROME score is the harmonic mean of the aggregate efficacy, paraphrase and neighborhood means.

## Historical or excluded outputs

| Artifact or location | Treatment |
|---|---|
| `A/models/deepseek-7b-base/run/` | **Exclude completely.** Broken tokenizer makes this original DeepSeek run invalid. Use B instead. |
| `A/models/gpt-j-6b/run/` | Superseded first-half output. Use B instead. |
| `A/models/ministral-3-8b/run/` | Superseded first-half output. Use B instead. |
| The 24 error cases in `A/models/qwen3.5-4b/run/` | Historical failed attempts. Use the matching completed cases from D in combined metrics. Retain A's other 476 completed cases. |
| GPT-2 Medium smoke in `results/smoke-gpt2-medium/` under the base campaign | Exclude from campaign totals. Its 10 facts overlap C. Use the indexed C run for GPT-2 Medium. |
| A's campaign-wide `report/` | Contains original first-half sources, including superseded/invalid runs and the Qwen failures. Do not use it as the final selected campaign aggregate. |
| B's campaign-wide `report/` | Corrected first-half subset for three models only. Does not cover all 18 models or all 1,000 facts. |
| Reports/graphs under `C/<model>/report/` | Valid second-half-only summaries (500 facts per model). Do not present them as combined 1,000-fact metrics. |
| D's `report/` and `validation.json` | Valid repair-only summaries (24 facts). Include those 24 cases once in Qwen's combined table. |
| `artifact-sources-1000-20261010.json` | Valid base-source map, but it predates the Qwen repair and reports 976 completed Qwen cases. Use the new selected-output-sources-20261011.json for the current selection. |
| `final-report-20261010.md`, `status-20261010.json`, `artifact-validation-20261010.json` | Audited second-half campaign records. They do not include the later 24-case repair or constitute the final combined 18,000-edit aggregate. |
| Submission plans, PBS logs, staging files, source archives, checkpoint/covariance caches | Provenance or execution inputs. Do not treat them as extra evaluated cases. |

Do not aggregate entire A or the entire base campaign results/ directory by globbing. Select the run directories in the table, then merge only the chosen completed case IDs.

## Baseline false positives remain valid control findings

**Gemma 4 12B, Llama 2 7B, Mistral 7B v0.1 and Mistral 7B v0.3** select the configured target layer in the unedited controls. Keep their valid execution/capture/analysis outputs, but mark this condition whenever reporting their 100% edited exact rates. Those rates do not establish discrimination between edited and unedited models.

## Frozen cohort and verification

Original frozen manifest:

```text
/storage/brno2/home/olexamatej/Latium-base-brno2-097ce88-20261009/counterfact_seed42_n1000.json
```

Original cohort manifest_hash: `7ce8d8044134b28347a92ff0d078c6d1ae00748b6450f2f42b7f81604c18c8a9`. It is the cohort identifier; it is not the SHA-256 of the JSON file's bytes.

The current audit checked the selected artifact identities/content hashes/config hashes and input/output references, frozen case IDs and dataset indices, disjoint halves, original-versus-retry settings, and the exact 24 replacement IDs. Every model has the same 1,000 selected IDs and 1,000 completed/evaluated edits.

Current combined counts: ROME efficacy success **17644/18000**; raw GRAM exact **14623/18000**, including the four models with baseline false positives.

Audit timestamp (UTC): `2026-10-11T20:49:36.386844+00:00`.
