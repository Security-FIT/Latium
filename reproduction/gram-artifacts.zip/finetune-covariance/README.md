# Finetuned GRAM / ROME with checkpoint-specific covariance

The archive contains 744 evaluated workflows: 550 full checkpoints and 194 merged adapters. Each workflow contains one unedited baseline, one ROME edit and GRAM analysis before and after the edit. There are 733 ROME efficacy successes and 11 evaluated efficacy failures.

The selection records 747 checkpoint attempts. Three unavailable downloads are excluded from the evaluated denominator. The fixed ROME fact pool contains 100 CounterFact facts; the indexes bind each checkpoint revision to its assigned fact.

Each evaluated checkpoint has a 100,000-sample covariance computation and cleanup receipt. Downloaded model weights and covariance tensors are not included. There are 727 accepted pre-ROME causal-tracing observations; availability is recorded in the checkpoint index.

## Layout

- `data/checkpoints.json` and `data/checkpoints.csv`: checkpoint identities, pinned revisions, assigned cases, outcomes and scientific artifact paths.
- `data/coverage.json` and `data/family-coverage.json`: population and family counts.
- `raw/`: scientific artifacts, exact configurations, selection manifests and computation receipts.
- Each `run/manifest.json` registers the baseline, ROME, GRAM and causal-tracing artifacts available for that workflow.
- `INDEX.json` and `INDEX.csv`: current file paths, sizes and SHA-256 hashes.
- `TRANSFER-VERIFICATION.json`: archive integrity verification.

Use the portable data indexes to locate the retained artifacts. Execution metadata may include the scratch paths used for computation. Model identities, fact assignments and scientific outputs are recorded in the saved configurations and manifests.

## Graphs

The graph scripts read the saved scientific artifacts. On kubapc they are under `/data/CSF-final-papers/scripts/`, with the Latium repository at `/data/olexa/Latium`.
