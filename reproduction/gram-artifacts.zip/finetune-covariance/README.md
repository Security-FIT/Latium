# Finetuned GRAM and ROME with checkpoint-specific covariance

744 evaluated checkpoints: 550 full checkpoints and 194 adapters. Each workflow
contains an unedited baseline, one ROME edit and GRAM analysis before and after
the edit. There are 733 ROME efficacy successes and 11 efficacy failures.

The selection contains 747 checkpoint attempts, of which 744 were downloadable.
Each checkpoint has one assigned fact from a fixed pool of 100 CounterFact
facts and a covariance computation using 100,000 texts on that checkpoint.

## Layout

- `data/checkpoints.json/csv`: checkpoint identities, pinned revisions, fact
  assignments, outcomes and scientific artifact paths.
- `data/coverage.json` and `data/family-coverage.json`: population and family counts.
- `raw/`: execution records, GRAM captures and analyses, configurations, fact
  selections and covariance computation receipts.
- `run/manifest.json`: artifact records for each checkpoint workflow.
- `SOURCE-INDEX.json/csv`: source-file catalogs.

The archive-level `INDEX.json` records file sizes and SHA-256 digests. The Latium
scripts resolve checkpoint inputs relative to this directory. Execution metadata
also records the paths used during computation.

## Metrics and figures

From the Latium repository root, follow `reproduction/README.md` to compute
per-checkpoint and per-family metrics. `python scripts/reproduce_paper.py`
generates the paper tables and figures from the saved observations.
