# Authoritative MetaCentrum outputs: finetunes with their own covariance

Snapshot validated: 2026-10-11 20:45 UTC. This guide selects the October 10–11 own-covariance rerun. It does not select every experiment ever saved on MetaCentrum.

## Start here

Account: `xsajko01@skirit.metacentrum.cz`.

**Use this fleet directory for the final finetuned/adaptor ROME and normal GRAM results:**

```text
/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2/runs/
```

The campaign contains 747 frozen checkpoints in 81 logical tasks. **744 downloaded checkpoints have complete scientific workflows: 550 full checkpoints and 194 merged adapters.** Three checkpoints failed download and have failure evidence only. Each evaluated checkpoint used its own freshly computed covariance, its original assigned CounterFact fact, baseline normal GRAM, one ROME edit, and edited normal GRAM.

The identifying PBS arrays are `24546306[].pbs-m1.metacentrum.cz` (72 large-GPU tasks) and `24546307[].pbs-m1.metacentrum.cz` (9 GPT-2 tasks). Folder names are logical task numbers, not necessarily PBS array indices. Use the job map/index below rather than guessing the mapping.

## Exact indexes: use these instead of a recursive wildcard

- [authoritative-checkpoints.csv](authoritative-checkpoints.csv): all 747 frozen model IDs, revisions, family, logical task, original fact, inclusion flag, outcome, and exact primary output paths. Filter `include_in_rome_gram_analysis=True` to select the 744 evaluated checkpoints. The three excluded rows retain their download failure reason.
- [authoritative-artifacts.csv](authoritative-artifacts.csv): **4,464 primary scientific JSON artifacts** (six per evaluated checkpoint) plus **727 accepted causal-kuba-fix artifacts**. Each row contains its exact MetaCentrum path, byte size, and SHA-256 of the copied file bytes. Manifest content hashes are separate fields because they describe the artifact payload rather than the raw file bytes.
- `/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2/checkpoint-job-map.json`: original frozen checkpoint-to-job/fact assignment map.

The indexes were generated from the final saved manifests and validated checkpoint states, not filename timestamps. The local archive was compared to the remote source with an rsync checksum dry run and no differences on October 11. These are a dated selection; a later separate rerun needs its own validated selection.

## Which files answer which question

For a selected row, let `MODEL` be the directory `runs/task-N/models/<key>` under the fleet root and `RUN` be `MODEL/run`. The exact paths are in the CSV indexes.

| Question | Authoritative output | Interpretation |
|---|---|---|
| What model, revision, base, and fact were selected? | `runs/task-N/checkpoints.json`, `checkpoint-configs/model/<key>.yaml`, `checkpoint-job-map.json` | Checkpoint identity, pinned adapter base, configured edit layer, and original assignment. These are inputs/provenance, not outcome counts. |
| Which science artifacts belong to this checkpoint? | `RUN/manifest.json` | Select the registered baseline and ROME records with `status=complete`; the artifact index already resolves their paths. |
| Did ROME change the requested fact, and what were its quality scores? | `RUN/plans/<key>/<plan>/methods/rome/execution.json` | Assigned case ID, efficacy, paraphrase, neighborhood, NLLs, modified layer, and outcome. |
| How did baseline normal GRAM behave? | `.../<plan>/baseline/captures/gram-localization.json` and its registered `baseline/analysis/detection/gram-localization/<hash>.json` | Layer scores before this ROME edit and the selected baseline layer. Baseline refers to the finetuned/merged checkpoint. |
| How did edited normal GRAM behave? | `.../<plan>/methods/rome/captures/gram-localization.json` and its registered `methods/rome/analysis/detection/gram-localization/<hash>.json` | Layer scores and localization after ROME. |
| Where are the paired checkpoint tables and graphs? | `RUN/graphs/gram-report/summary.json`, `cases.json`, `cases.csv`, `profiles.png`, `accuracy.png` | Derived from the authoritative raw artifacts. Use the JSON/CSV for numbers; PNGs are views of those numbers. |
| Which causal trace is the accepted result? | `RUN/causal-kuba-fix/m<trace-position>/artifact.json` identified by the final state's `trace.accepted_position` | There are 727 accepted trace artifacts. Its fact comes from the separate tracing manifest and is not the assigned ROME fact. |
| Was the checkpoint processed and covariance removed? | `MODEL/fleet-batches/*/state.json`, `MODEL/batches/m<fact>-m<next>/state.json`, `MODEL/covariance-lifecycle.json` | Download/computation timestamps, revision, matrix filename, checksum recorded at cleanup, outcomes, and deletion receipt. |
| Are there any leftover covariances or weights? | `runs/task-N/covariance-leftovers.txt` and `download-leftovers.txt` | Both are empty for all 81 final tasks. |

All 744 checkpoint workflows retain baseline/ROME execution, capture, and analysis records. Do not pick an analysis by its hashed basename alone; resolve it through the corresponding manifest or the CSV index.

## Failed outcomes that are still correct scientific outputs

**Do not filter the final experiment down to positive outcomes.** The eight `rome_failed` checkpoint states mean the edit ran and was evaluated but failed the efficacy criterion. Their covariance, ROME, baseline GRAM, and edited GRAM artifacts are valid final outputs and belong in the 744-checkpoint denominator.

Likewise, the 158 edited GRAM misses are valid measured outcomes. The 17 checkpoints without an accepted trace still have complete ROME/GRAM results; their saved trace scans/rejections are diagnostics, not additional edits.

The three HTTP 404 download failures belong in attempted/download coverage (747 attempted, 744 downloaded), but not ROME/GRAM outcome denominators. Their rows are explicitly excluded in the checkpoint index.

Sanity-check totals for this specific campaign:

| Measure | Final value |
|---|---:|
| Attempted checkpoints | 747 |
| Downloaded and scientifically evaluated | 744 |
| Baseline / edited normal GRAM captures | 744 / 744 |
| ROME efficacy passed / failed | 736 / 8 |
| Edited GRAM exact / missed | 586 / 158 |
| Baseline peak coincides with future edit layer | 159 / 744 |
| Accepted causal traces / unavailable | 727 / 17 |

Normal GRAM always selects an eligible layer. Baseline layer coincidence is a control statistic, not a calibrated binary no-edit accuracy.

## Files to keep for provenance but not use as extra result rows

| Location | Role |
|---|---|
| `/storage/brno2/home/xsajko01/Latium-owncov-20261010/historical-inputs/` | The original shared ROME facts, tracing facts, frozen selections, and prefix caches actually used to prepare this rerun. These are needed inputs; they are not another evaluated campaign. |
| `/storage/brno2/home/xsajko01/Latium-owncov-20261010/runtime/` | Portable Python runtime and dataset archives. The 3.49 GB Python archive is a dependency, not a scientific output. |
| `/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2/code.tar.gz`, `scientific-config-comparison.json`, `input-validation.json`, submission/job maps | Executed code, configuration comparisons, and assignment provenance. Keep them to reproduce or audit the run; do not count fixture/sample outputs embedded in source trees. |
| `/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2/pbs-logs/`, per-task `pbs-job.log` / `fleet.log` | Execution and covariance-selection evidence. Multiple log copies are not multiple scientific runs. |
| Per-task `report-hotfix-recovery.json` | Final report-rendering recovery record. Recovery regenerated reports from saved science; it did not redo downloads, covariance, or edits. |
| `RUN/causal-kuba-fix/scans/` | Trace candidate/rejection history. Select only the final accepted trace named in the index for trace-result comparisons. |

## Exclude these from this rerun's final result selection

| Location or type | Why it is excluded |
|---|---|
| `/storage/brno2/home/xsajko01/Latium-owncov-20261010/smoke-qwen3-8b/` | Setup/smoke campaign. It is not an additional observation in the 744-checkpoint final fleet. |
| Earlier or cancelled arrays such as `24546090[]` and `24546091[]` | Earlier submissions; use the final fleet directory and frozen job map named above. |
| `/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2/hotfix-20261011/` as a source of scientific result rows | Recovery/source/forensic material, including source fixtures and old code snapshots. Use final `runs/task-N/...` artifacts instead. |
| `budget-summary.json.before-report-hotfix` and original report-error states/log lines | Historical state before rendering recovery. Use current `budget-summary.json`, final states, recovery receipts, and registered completed scientific artifacts. Original PBS exit codes are preserved and may reflect report errors even when science is complete. |
| Older olexamatej finetune roots listed below | Earlier base-covariance campaigns, pilots, retries, or intermediate selections. They do not replace or supplement this own-covariance experiment's outcomes. |
| Historical `gram-directional-error-v1.json`, `spectral.json`, and other capture/detector experiments | Different analyses. The requested rerun uses normal `gram-localization` baseline/edited artifacts, not historical basis-array experiments. |
| Any retained original/base-model covariance tensor elsewhere | It was not this checkpoint's computed matrix. Do not substitute it for the deleted own-covariance tensors. |
| Scratch paths such as `/scratch.../job_24546306.../` | Temporary execution locations; use the permanent Brno2 copies. Absolute scratch paths inside saved payloads/logs are provenance, not the current location of those result files. |

Examples of historical finetune roots on the source account, excluded **for this own-covariance report**:

```text
/brno2/olexamatej/Latium-finetuned-gram-20261003/
/brno2/olexamatej/Latium-finetuned-gram-exact-20261003/
/brno2/olexamatej/Latium-finetuned-gram-basecov-20261004/
/brno2/olexamatej/Latium-finetune-tokens-ft20-20261004/
/brno2/olexamatej/Latium-adapter-fleet-20261005/
/brno2/olexamatej/Latium-adapter-fleet-random-20261005/
/brno2/olexamatej/Latium-shared-facts-20261005/
/brno2/olexamatej/Latium-quota-retry-20261006/
/brno2/olexamatej/Latium-scratch-remainder-20261007-155240/
/brno2/olexamatej/Latium-scratch-qwen8b-20261007-125050/
/brno2/olexamatej/Latium-remaining-eligible-20261008-171001/
/brno2/olexamatej/Latium-remaining-lgm-20261009-095423/
/brno2/olexamatej/Latium-remaining-olmo-20261009-101748/
```

"Historical" here does not mean corrupt or safe to delete. Those runs remain comparison/provenance evidence. The separate base-model campaign (18 families, up to 1,000 facts each) is a different experiment and is not superseded by this finetune rerun. If reporting it separately, use its validated selected-source map; do not pool all historical attempts or add its edits to this campaign's denominator.

## Family and task locations

Every row below is relative to `/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2/runs/`.

| Family | Logical task directories | Attempted | Evaluated |
|---|---|---:|---:|
| deepseek-7b-base | `task-1` | 8 | 8 |
| falcon-7b | `task-2..task-5` | 36 | 36 |
| gpt-j-6b | `task-6` | 10 | 10 |
| gpt2-large | `task-7..task-9` | 48 | 48 |
| gpt2-medium | `task-10..task-13` | 63 | 63 |
| gpt2-xl | `task-14..task-15` | 21 | 21 |
| granite-4.1-8b | `task-16` | 4 | 4 |
| granite4-micro | `task-17..task-22` | 57 | 57 |
| llama2-7b | `task-23..task-24` | 18 | 18 |
| ministral-3-8b | `task-25` | 2 | 2 |
| mistral-7b-v0.1 | `task-26..task-34` | 72 | 72 |
| mistral-7b-v0.3 | `task-35..task-45` | 85 | 85 |
| olmo-3-1025-7b | `task-46..task-54` | 72 | 70 |
| opt-6.7b | `task-55` | 3 | 3 |
| qwen3-4b | `task-56..task-62` | 85 | 85 |
| qwen3-8b | `task-63..task-70` | 82 | 82 |
| qwen3.5-4b | `task-71..task-81` | 81 | 80 |

## MetaCentrum path aliases and local mirror

The following are aliases for the same permanent xsajko01 campaign root, not separate copies to aggregate:

| Access surface | Root |
|---|---|
| MetaCentrum frontend | `/storage/brno2/home/xsajko01/Latium-owncov-20261010/` |
| Canonical frontend path used by the transfer | `/auto/brno2/brno2/xsajko01/Latium-owncov-20261010/` |
| `storage-brno2.metacentrum.cz` | `/brno2/xsajko01/Latium-owncov-20261010/` |
| Verified local cluster mirror | `/home/metju/Latium/CSF-paper-final/cluster/` |

To use a direct-storage path from the indexes, replace the prefix `/storage/brno2/home/xsajko01/Latium-owncov-20261010` with `/brno2/xsajko01/Latium-owncov-20261010`. The remainder is identical.

The final combined human-readable report and PDF were generated locally at `/home/metju/Latium/CSF-paper-final/final_report.md` and `final_report.pdf`; figures and checkpoint/family tables are under that local folder's `figures/` and `data/`. Those aggregate reports are not asserted to be present on MetaCentrum unless separately copied there. The permanent cluster copies contain the primary scientific artifacts and per-checkpoint reports identified above.

## Covariance evidence and its limit

All 744 evaluated checkpoints passed the detailed provenance audit: their pinned configuration, fresh 100,000-sample computation, checkpoint-specific matrix path, ROME's selection and actual matrix consumption, adapter merge, and post-edit cleanup agree. No other selected matrix, reuse, or automatic ROME covariance computation was observed.

The matrices and downloaded model/base weights were deleted as requested. SHA-256 was recorded at cleanup after ROME; no separate computation-time/loading-time checksum pair was recorded. The saved logs, configuration hashes, source hashes, and receipts establish the executed workflow, but cannot now provide a retrospective byte-for-byte check of the deleted matrix at loading time. Do not claim those tensors are retained in the final output folder.

## How this guide was validated

The six primary artifacts were resolved through every final run manifest and checked present/complete for all 744 evaluated checkpoints. The 727 accepted trace paths were selected through final trace states and checked present/complete. Model IDs, revisions, original facts, and job/task mapping come from the frozen selection and job map. Exact file-byte SHA-256 hashes are in `authoritative-artifacts.csv`.

Full local validation receipts are in `/home/metju/Latium/CSF-paper-final/transfer/verification.json`, `transfer/local-artifact-validation.json`, and `validation/covariance-audit/VALIDATION.md`. This guide does not submit jobs, recompute experiments, or remove any evidence.
