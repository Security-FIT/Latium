# Submitted own-covariance finetune rerun

Account: `xsajko01@skirit.metacentrum.cz`. Scheduler verified at 2026-10-10T20:50:24+02:00.

747 previously successful checkpoint workflows (553 full checkpoints, 194 adapters) across 17 families, divided into 81 PBS subjobs. The submitted cohort exactly preserves the historical checkpoint revisions, pinned adapter bases, shared CounterFact assignments, and classic scientific settings. No new HF selection or ranking was performed.

| Profile | Parent job ID | Subjobs | Concurrent limit | Minimum GPU VRAM | Walltime |
|---|---|---:|---:|---:|---|
| large | `24546306[].pbs-m1.metacentrum.cz` | 72 | 72 | 40 GB | 24 hours |
| gpt2 | `24546307[].pbs-m1.metacentrum.cz` | 9 | 9 | 16 GB | 24 hours |

Each subjob requests one GPU, 4 CPUs, 64 GB RAM, 100 GB local scratch, and CUDA capability compute_80 or newer. PBS resource `gpu_mem` is a minimum, so PBS may assign a larger GPU. [MetaCentrum GPU resource documentation](https://docs.metacentrum.cz/en/docs/computing/gpu-comput/gpu-job).

The runtime work deadline is 19.5 hours from the start of the PBS script. New checkpoints are deferred unless their family budget or observed runtime (with a 50% multiplier) plus transfer allowance fits before that deadline. An in-flight worker has a bounded timeout and its process group is stopped before deletion. Cleanup and transfers have their own bounded timeouts. Unstarted checkpoints are recorded in `budget-summary.json` as pending; they need a continuation if a batch cannot finish within its budget.

Each checkpoint loads or merges its own pinned weights, computes a dedicated covariance from 100,000 samples, runs baseline normal GRAM, one ROME edit for its assigned fact, and edited normal GRAM. The corrected causal-kuba-fix tracing implementation and separate 900-case tracing manifest are preserved. Covariance provenance and scientific artifacts are retained; covariance matrices and downloaded checkpoint/base weights are removed after each checkpoint.

Latest submission snapshot: {'Q': 81}. These are scheduler states; the complete fleet has not yet been validated.

GPU inventory before submission: 68 matching nodes (67 online), 221 online installed GPUs, and 12 currently unallocated slots after CPU/RAM/scratch requirements. Reservations, other jobs, and scheduler fairness can delay placement.

| Family | Checkpoints | Batches | Checkpoint planning budget | Minimum GPU VRAM |
|---|---:|---:|---:|---:|
| deepseek-7b-base | 8 | 1 | 90 minutes | 40 GB |
| falcon-7b | 36 | 4 | 90 minutes | 40 GB |
| gpt-j-6b | 10 | 1 | 90 minutes | 40 GB |
| gpt2-large | 48 | 3 | 60 minutes | 16 GB |
| gpt2-medium | 63 | 4 | 60 minutes | 16 GB |
| gpt2-xl | 21 | 2 | 60 minutes | 16 GB |
| granite-4.1-8b | 4 | 1 | 120 minutes | 40 GB |
| granite4-micro | 57 | 6 | 90 minutes | 40 GB |
| llama2-7b | 18 | 2 | 90 minutes | 40 GB |
| ministral-3-8b | 2 | 1 | 120 minutes | 40 GB |
| mistral-7b-v0.1 | 72 | 9 | 120 minutes | 40 GB |
| mistral-7b-v0.3 | 85 | 11 | 120 minutes | 40 GB |
| olmo-3-1025-7b | 72 | 9 | 120 minutes | 40 GB |
| opt-6.7b | 3 | 1 | 90 minutes | 40 GB |
| qwen3-4b | 85 | 7 | 75 minutes | 40 GB |
| qwen3-8b | 82 | 8 | 90 minutes | 40 GB |
| qwen3.5-4b | 81 | 11 | 120 minutes | 40 GB |

Replacement arrays were released after the Hugging Face token was installed and authenticated using the job runtime (HF account `metjuas`). Each PBS script explicitly fetches the private account token into its own scratch HF_TOKEN_PATH. The credential is stored with mode 0600 and is excluded from source archives, PBS metadata, and result artifacts.

The original arrays 24546090[] and 24546091[] were cancelled and superseded by these arrays. Two original subjobs failed during conda-unpack before any model download because their scratch path exceeded the runtime binary prefix length. The corrected wrapper uses a private short symlink prefix; full runtime unpack, relocation, library imports, and tensor operation passed on an intentionally long path.

All 81 subjobs may run concurrently, subject to PBS scheduling. Original checkpoint revisions, pinned adapter bases, facts, and scientific settings are unchanged.

Only Qwen3-8B own-covariance timing has been measured directly in the completed smoke; other families use conservative planning budgets and the absolute runtime guard. A 40 GB minimum gives more VRAM headroom, but successful execution of every family is still to be verified.

Validation: 46 local lifecycle, runtime guard, frozen selection, and tracing tests passed. All 81 frozen batches / 747 checkpoints passed prepare-only checks without discovery calls or weight downloads. All 17 deployed classic configs matched their frozen historical scientific fields. The code archive checksum was verified on the submission host.

Code archive SHA256: `6097fbff19c2f1c4e6941fbe5f23b8e50ee3a71f0005f3ce3e1bfc2ac75c078d`.

Permanent deployment and results root: `/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2`.
PBS logs: `/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2/pbs-logs/`.
Per-batch artifacts: `/storage/brno2/home/xsajko01/Latium-owncov-20261010/fleet-worked747-40gb-r2/runs/task-<logical_batch_index>/`.

The local and permanent deployment directories contain `submitted-jobs.json`, `submitted-plan.json`, `checkpoint-job-map.json`, `input-validation.json`, `frozen-preflight.json`, `scientific-config-comparison.json`, and PBS scheduler snapshots.

## Reporting hotfix — 11 October 2026

The existing arrays were hotfixed in place for the Hydra array-path reporting error. Running jobs were patched; queued jobs now fetch corrected code. No GPU batches were cancelled or resubmitted. Full details are in [HOTFIX.md](hotfix-20261011/HOTFIX.md). The original submission code checksum above remains the historical submission checksum; the effective hotfix checksum is `5b8cb2b0b5ff123aab08452a82cccd2d8f71212dcddcc656b5ba308eade969e5`.

CPU report recovery completed successfully: 99 checkpoints across 12 finished batches, repair job `24557148.pbs-m1.metacentrum.cz`, exit 0. New checkpoints are completing with the hotfixed reporting code; the full fleet remains in progress.
