# Finetuned GRAM and ROME with base-model covariance

790 checkpoint workflows using their base model's covariance. Each workflow
contains one ROME edit and paired unedited/edited GRAM observations. There are
747 ROME efficacy successes and 43 efficacy failures.

This cohort supplies the preliminary checkpoint selection for the
checkpoint-specific covariance experiment and supports comparison between the
two covariance settings.

## Layout

- `data/checkpoints.json/csv`: checkpoint identities, revisions, fact assignments,
  outcomes and artifact paths.
- `data/coverage.json` and `data/family-coverage.json`: population and family counts.
- `raw/`: execution records, GRAM captures and analyses, configurations and
  selection manifests, organized by checkpoint workflow.
- `run/manifest.json`: artifact records for each workflow.
- `SOURCE-INDEX.json/csv`: source-file catalogs.

The archive-level `INDEX.json` records file sizes and SHA-256 digests. The Latium
scripts resolve input paths relative to this directory. Metadata also records
the absolute paths used during computation.

## Metrics and figures

From the Latium repository root, follow `reproduction/README.md` to compute
metrics and generate figures. The paper notebooks use this cohort for the
checkpoint-selection analysis.
