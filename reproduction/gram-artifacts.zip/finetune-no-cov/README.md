# Finetune GRAM / ROME using base covariance

790 complete checkpoint workflows, each with one ROME edit and paired baseline/edited normal GRAM. There are 747 ROME efficacy successes and 43 valid efficacy failures. Keep all 790 workflows. There are 766 accepted pre-ROME causal traces from a separate tracing fact pool.

This campaign reused base-model covariance; "no-cov" means no checkpoint-specific covariance computation, not absence of a covariance input to ROME.

Excluded: historical pilots/reserve-fact/random-fact/alternative-GRAM result trees, unavailable/rejected tracing artifacts, 19 trace-only checkpoint identities, and the partial iko-01/iko-002 run with NaN weights and failed post-edit GRAM. Those exclusions are not additional result rows in this bundle.

## Layout and selection

- data/: portable selected-checkpoint/case indexes with absolute paths on kubapc, coverage and per-family counts.
- raw/: exact selected source file bytes, retaining source hierarchy so relative artifact/report paths work.
- Each run/manifest.json is a filtered selection manifest containing only the transferred primary science, accepted trace and graph artifact records. The source manifest hash and removed-record count are in its transfer_selection metadata and provenance/source-manifests.json. Artifact bytes and content hashes were not rewritten.
- INDEX.csv / INDEX.json: exact copied file paths, roles, byte sizes and SHA-256 hashes; source account/path are recorded.
- TRANSFER-VERIFICATION.json: destination-side full SHA-256 verification receipt.

Raw payloads/logs may retain original absolute scratch paths. Use the portable data indexes and INDEX files to find the permanent copied artifacts. Per-fleet checkpoints/state/log files are provenance and can describe attempted or rejected work; they are not extra result rows. Accepted trace summaries retain scan/rejection diagnostics, while only their accepted raw profile files are copied.

This is a verified artifact copy; MetaCentrum source files remain intact. Runtime archives, cached weights, covariance tensors, alternative analyses and superseded scientific result trees are excluded. The bundle preserves scientific outputs and selected provenance; it is not a standalone environment for rerunning models.
